// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : currently experimental : include manually




#ifndef _H_NONNON_NEUTRAL_BMP_UI_ROUNDFRAME
#define _H_NONNON_NEUTRAL_BMP_UI_ROUNDFRAME




#include "../all.c"




void
n_bmp_ui_roundframe
(
	n_bmp *bmp,
	s32    x,
	s32    y,
	s32    sx,
	s32    sy,
	s32    round,
	s32    frame,
	u32    color_fg,
	u32    color_bg
)
{
//return;

	s32 m, mm;


	m  = 0;
	mm = m * 2;
	n_bmp_roundrect( bmp, x+m,y+m,sx-mm,sy-mm, color_fg, round );

	m  = frame;
	mm = m * 2;
	//n_bmp_roundrect( bmp, x+m,y+m,sx-mm,sy-mm, color_bg, round );

	double coeff = (double) 0.005 * round;
	n_bmp_roundrect_main( bmp, NULL, x+m,y+m,sx-mm,sy-mm, 0,0, color_bg, round, coeff, 1.0 );


	return;
}

void
n_bmp_ui_roundframe_dropshadow( n_bmp *bmp, s32 sx, s32 sy, s32 shadow_size, s32 round_param, n_posix_bool darkmode_onoff )
{

	s32 ss = shadow_size;
	s32 m  = ss / 2;
	s32 mm =  m * 2;

	n_bmp bmp_shadow; n_bmp_zero( &bmp_shadow ); n_bmp_new( &bmp_shadow, sx, sy );

	bmp_shadow.transparent_onoff = n_posix_false;

	n_bmp_roundrect( &bmp_shadow, m,m,sx-mm,sy-mm, n_bmp_white, round_param );

	int i = 0;
	while( 1 )
	{//break;
		n_bmp_flush_antialias( &bmp_shadow, 1.0 );

		i++;
		if ( i >= ss ) { break; }
	}

//n_bmp_save_literal( &bmp_shadow, "shadow.bmp" );

	u32 color;
	if ( darkmode_onoff )
	{
		color = n_bmp_rgb(  50, 50, 50 );
	} else {
		color = n_bmp_rgb( 100,100,100 );
	}

	n_bmp_rasterizer( &bmp_shadow, bmp, ss,ss, color, n_posix_false );

	n_bmp_free_fast( &bmp_shadow );


	return;
}




#endif // _H_NONNON_NEUTRAL_BMP_UI_ROUNDFRAME

