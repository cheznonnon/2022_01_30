// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : currently experimental : include manually




#ifndef _H_NONNON_NEUTRAL_BMP_UI_ROUNDFRAME
#define _H_NONNON_NEUTRAL_BMP_UI_ROUNDFRAME




#include "../all.c"




void
n_bmp_ui_roundframe
(
	n_bmp      *bmp,
	n_type_gfx   x,
	n_type_gfx   y,
	n_type_gfx  sx,
	n_type_gfx  sy,
	n_type_gfx  round,
	n_type_gfx  frame,
	u32         color_fg,
	u32         color_bg
)
{
//return;

	n_type_gfx m, mm;


	m  = 0;
	mm = m * 2;
	n_bmp_roundrect( bmp, x+m,y+m,sx-mm,sy-mm, color_fg, round );

	m  = frame;
	mm = m * 2;
	//n_bmp_roundrect( bmp, x+m,y+m,sx-mm,sy-mm, color_bg, round );

	double coeff = (double) 0.005 * round;
	n_bmp_roundrect_main( bmp, NULL, x+m,y+m,sx-mm,sy-mm, 0,0, color_bg, round, coeff, 1.0 );


	return;
}

void
n_bmp_ui_roundframe_dropshadow( n_bmp *bmp, n_type_gfx sx, n_type_gfx sy, n_type_gfx shadow_size, n_type_gfx round_param, n_posix_bool darkmode_onoff )
{

	n_type_gfx ss = shadow_size;
	n_type_gfx m  = ss / 2;
	n_type_gfx mm =  m * 2;

	n_bmp bmp_shadow; n_bmp_zero( &bmp_shadow ); n_bmp_new( &bmp_shadow, sx, sy );

	bmp_shadow.transparent_onoff = n_posix_false;

	n_bmp_roundrect( &bmp_shadow, m,m,sx-mm,sy-mm, n_bmp_white, round_param );

	n_type_gfx i = 0;
	while( 1 )
	{//break;
		n_bmp_flush_antialias( &bmp_shadow, 1.0 );

		i++;
		if ( i >= ss ) { break; }
	}

//n_bmp_save_literal( &bmp_shadow, "shadow.bmp" );

	u32 color;
	if ( darkmode_onoff )
	{
		color = n_bmp_rgb(  50, 50, 50 );
	} else {
		color = n_bmp_rgb( 100,100,100 );
	}

	n_bmp_rasterizer( &bmp_shadow, bmp, ss,ss, color, n_posix_false );

	n_bmp_free_fast( &bmp_shadow );


	return;
}

void
n_bmp_ui_roundframe_fogshadow( n_bmp *bmp, n_type_gfx shadow_size, n_type_gfx round_param, n_posix_bool darkmode_onoff )
{

	n_type_gfx sh_sx = N_BMP_SX( bmp );
	n_type_gfx sh_sy = N_BMP_SY( bmp );

	n_bmp bmp_shadow; n_bmp_zero( &bmp_shadow ); n_bmp_new( &bmp_shadow, sh_sx, sh_sy );

	bmp_shadow.transparent_onoff = n_posix_false;


	n_type_gfx sh_x = shadow_size / 2;
	n_type_gfx sh_y = shadow_size / 2; sh_y += round_param / 2;

	sh_sx -= sh_x * 2;
	sh_sy -= sh_y * 2;

	n_bmp_roundrect( &bmp_shadow, sh_x, sh_y, sh_sx, sh_sy, n_bmp_rgb( 150,150,150 ), round_param );


	n_type_gfx times = sh_y * 2;

	n_type_gfx i = 0;
	while( 1 )
	{//break;
		n_bmp_flush_antialias( &bmp_shadow, 1.0 );

		i++;
		if ( i >= times ) { break; }
	}

//n_bmp_save_literal( &bmp_shadow, "shadow.bmp" );


	u32 color;
	if ( darkmode_onoff )
	{
		color = n_bmp_rgb(  50, 50, 50 );
	} else {
		color = n_bmp_rgb( 100,100,100 );
	}

	n_bmp_rasterizer( &bmp_shadow, bmp, 0,0, color, n_posix_false );

	n_bmp_free_fast( &bmp_shadow );


	return;
}




#endif // _H_NONNON_NEUTRAL_BMP_UI_ROUNDFRAME

