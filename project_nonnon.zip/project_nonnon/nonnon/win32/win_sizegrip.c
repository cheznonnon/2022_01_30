// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	for dark mode support only
//
//	[ WM_CREATE ]
//
//	1st : n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS,  "", &hgui_dark );
//	2nd : n_win_gui_literal( hwnd, N_WIN_GUI_VSCROLL, "", &hgui_main ); n_win_style_add( hgui_main, SBS_SIZEGRIP );
//
//	[ WndProc() ]
//
//	n_win_sizegirp_proc( ..., hgui_dark )
//
//	+ you make two controls because of flicker prevention
//	+ SetWindowPos() cannot resolve flicker, see below code




#ifndef _H_NONNON_WIN32_WIN_SIZEGRIP
#define _H_NONNON_WIN32_WIN_SIZEGRIP




#include "./gdi/doublebuffer.c"

#include "./win.c"

#include "./uxtheme.c"




void
n_win_sizegrip_status_gradient( HWND hgui, HDC hdc, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_type_gfx scale, COLORREF ln, COLORREF bg )
{

	n_type_gfx unit = ( 4 * scale );

	n_type_gfx oy = 0;
	while( 1 )
	{//break;

		COLORREF color = n_win_color_blend(    ln, bg, (double) oy / unit );
		         color = n_win_color_blend( color, bg,                0.5 );

		RECT r = { x, y + sy - oy - ( scale * 2 ), x + sx, y + sy - oy - ( scale * 2 ) + scale };
		n_win_box( hgui, hdc, &r, color );

		oy++;
		if ( oy >= unit ) { break; }
	}


	return;
}

n_type_gfx
n_win_sizegrip_stdsize( void )
{
	return GetSystemMetrics( SM_CYHSCROLL );
}

n_type_gfx
n_win_sizegrip_offset( HWND hgui )
{

	// [!] : Classic Theme : TextOut() needs stdsize, but margin will be made


	HDC hdc = GetDC( hgui );


	n_type_gfx stdsize = n_win_sizegrip_stdsize();


	HFONT  hfont = n_win_font_name2hfont( n_posix_literal( "Marlett" ), stdsize );
	HFONT phfont = SelectObject( hdc, hfont );

	n_posix_char str[ 2 ] = { 0x70, 0x00 };

	SIZE size;
	GetTextExtentPoint32( hdc, str, n_posix_strlen( str ), &size );

	SelectObject( hdc, phfont );


	ReleaseDC( hgui, hdc );


	return ( size.cy / 4 );
}

// internal
void
n_win_sizegrip_draw( HWND hgui, RECT *rect, n_posix_bool statusbar_onoff )
{

	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	HDC hdc = n_gdi_doublebuffer_simple_init( hgui, sx,sy );


	n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
	n_uxtheme_init( &uxtheme, hgui, L"WINDOW" );

	if ( uxtheme.onoff )
	{

/*
		n_uxtheme_init( &uxtheme, hgui, L"SCROLLBAR" );

		int part  = 10;
		int state = 0;

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, rect, NULL );
*/

		n_posix_bool is_vista_or_later = n_sysinfo_version_vista_or_later();
		n_posix_bool is_8_or_later     = n_sysinfo_version_8_or_later();


		COLORREF bg = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE   );
		COLORREF fg = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW );
		COLORREF ln = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW );


		double scale = n_win_scale( hgui );


		SetBkMode( hdc, TRANSPARENT );
		n_win_box( hgui, hdc, rect, bg );

		if ( ( is_vista_or_later == n_posix_false )&&( statusbar_onoff ) )
		{
			n_win_sizegrip_status_gradient( hgui, hdc, x, y, sx, sy, scale, ln, bg );
		}


		// [!] : "step" : Nonnon Original Behavior
		//
		//	Win32 uses always 1px for gap

		n_type_gfx box   = 1 + ceil( scale );
		n_type_gfx step  = box * 2;

		n_type_gfx ox    = sx - ( step * 3 ) - scale;
		n_type_gfx oy    = sy - ( step * 3 ) - scale;


		n_type_gfx cx = 0;
		n_type_gfx cy = 0;
		n_type_gfx xx = 0;
		n_type_gfx yy = 0;
		while( 1 )
		{//break;

			if ( ( yy == ( step * 0 ) )&&( xx < ( step * 2 ) ) )
			{
				//
			} else
			if ( ( yy == ( step * 1 ) )&&( xx < ( step * 1 ) ) )
			{
				//
			} else {
				if ( n_posix_false == is_8_or_later )
				{
					n_type_gfx m = scale;
					RECT r = { ox+xx+m,oy+yy+m,ox+xx+m+box,oy+yy+m+box };
					n_win_box( hgui, hdc, &r, RGB( 255,255,255 ) );
				}
				RECT r = { ox+xx,oy+yy,ox+xx+box,oy+yy+box };
				n_win_box( hgui, hdc, &r, fg );
			}

			cx++;
			xx += step;
			if ( ( xx >= sx )||( cx >= 3 ) )
			{
				xx = cx = 0;
				cy++;
				yy += step;
				if ( ( yy >= sy )||( cy >= 3 ) ) { break; }
			}
		}

	} else {

//SetBkColor( hdc, RGB( 10,10,10 ) );
//DrawFrameControl( hdc, rect, DFC_SCROLL, DFCS_SCROLLSIZEGRIP );

		COLORREF bg = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE   );
		COLORREF fg = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW );
		COLORREF mg = n_win_darkmode_systemcolor_ui( COLOR_WINDOW    );

		if ( n_win_darkmode_onoff )
		{
			mg = n_win_darkmode_systemcolor_ui( COLOR_3DLIGHT );
		}


		SetBkMode( hdc, TRANSPARENT );
		n_win_box( hgui, hdc, rect, bg );

		HFONT  hfont = n_win_font_name2hfont( n_posix_literal( "Marlett" ), sx );
		HFONT phfont = SelectObject( hdc, hfont );

		n_posix_char str[ 2 ] = { 0x70, 0x00 };

		if ( ( n_win_style_is_classic() )&&( statusbar_onoff ) )
		{
			n_type_gfx o = n_win_sizegrip_offset( hgui );

			x -= o;
			y -= o;
		}

		SetTextColor( hdc, mg );
		TextOut( hdc, x-1,y-1, str, 1 );

		SetTextColor( hdc, fg );
		TextOut( hdc, x,y, str, 1 );

		SelectObject( hdc, phfont );

	}

	n_uxtheme_exit( &uxtheme, hgui );


	if ( n_win_dwm_is_on() ) { n_gdi_doublebuffer_visible( &n_gdi_doublebuffer_instance ); }

	n_gdi_doublebuffer_simple_exit();


	return;
}

#define n_win_sizegrip_proc(           h, m, w, l, hgui ) n_win_sizegrip_proc_internal( h, m, w, l, hgui, n_posix_false )
#define n_win_sizegrip_proc_statusbar( h, m, w, l, hgui ) n_win_sizegrip_proc_internal( h, m, w, l, hgui, n_posix_true  )

void
n_win_sizegrip_proc_internal( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui, n_posix_bool statusbar_onoff )
{

	// [x] : flicker happens with controls

	//static n_posix_bool onoff = n_posix_false;
	//static n_type_gfx   px    = 0;
	//static n_type_gfx   py    = 0;


	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( hgui != di->hwndItem ) { break; }


		n_win_sizegrip_draw( hgui, &di->rcItem, statusbar_onoff );

	}
	break;

/*
	case WM_MOUSEMOVE :

		if ( onoff )
		{

			n_type_gfx x,y; n_win_cursor_position( &x,&y );

			n_type_gfx csx,csy; n_win_size( hwnd, &csx,&csy );

			UINT swp = SWP_NOMOVE;// | SWP_NOREDRAW | SWP_NOSENDCHANGING;
			SetWindowPos( hwnd, NULL, 0,0, csx + ( x - px ), csy + ( y - py ), swp );

			px = x;
			py = y;

		}

		if ( n_win_is_hovered( hgui ) )
		{
			n_win_cursor_add( NULL, IDC_SIZENWSE );
		} else {
			n_win_cursor_add( NULL, IDC_ARROW );
		}

	break;

	case WM_LBUTTONDOWN :

		if ( n_win_is_hovered( hgui ) )
		{

			onoff = n_posix_true;

			n_win_cursor_position( &px,&py );

			SetCapture( hwnd );

			n_win_cursor_add( NULL, IDC_SIZENWSE );

		}

	break;

	case WM_LBUTTONUP :

		if ( onoff )
		{
			onoff = n_posix_false;

			ReleaseCapture();

			n_win_cursor_add( NULL, IDC_ARROW );
		}

	break;
*/

	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_SIZEGRIP


/*


#include "../project/macro.c"


LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;


	switch( msg ) {


	case WM_CREATE :


		n_project_darkmode();
		//n_win_darkmode_onoff = n_posix_true;


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "", &hgui );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		const n_posix_bool redraw = n_posix_true;

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_DEFAULT );

		n_type_gfx ctl = GetSystemMetrics( SM_CYVSCROLL );
		//n_type_gfx ctl; n_win_stdsize( hgui, &ctl, NULL, NULL ); 

		n_win_move( hgui, w.csx-ctl+1,w.csy-ctl+1, ctl,ctl, redraw );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_sizegrip_proc( hwnd,msg,wparam,lparam, hgui );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

*/

