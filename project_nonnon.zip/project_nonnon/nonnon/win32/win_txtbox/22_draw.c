// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "./22_draw_00_bmp.c"
#include "./22_draw_01_base.c"
#include "./22_draw_02_parts.c"
#include "./22_draw_03_singleline.c"




// internal
void
n_win_txtbox_draw_bitblt( n_win_txtbox *p, HDC hdc_main, HDC hdc_cmpt, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy )
{

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
//return;
		n_type_gfx bmpsx = N_BMP_SX( &p->bmp );
		n_type_gfx bmpsy = N_BMP_SY( &p->bmp );

		n_type_gfx fx  = p->border_pxl_sx + p->pad_pxl_sx;
		n_type_gfx fy  = p->border_pxl_sy + p->pad_pxl_sy;
		n_type_gfx fsx = bmpsx - ( fx * 2 ) - p->smallbutton_margin;
		n_type_gfx fsy = bmpsy - ( fy * 2 );

		n_bmp bmp_fog; n_bmp_carboncopy( &p->bmp, &bmp_fog );
		n_bmp bmp_txt; n_bmp_carboncopy( &p->bmp, &bmp_txt );

		n_bmp_free( &p->bmp_oneline ); n_bmp_carboncopy( &p->bmp, &p->bmp_oneline );

		n_bmp_box( &bmp_fog, sx - p->smallbutton_margin, 0, p->smallbutton_margin, sy, 0 );

		if ( p->selection_onoff )
		{
			COLORREF bg = n_win_color_blend( p->color_back_selected, p->color_back_noselect, p->text_fade_ratio );

			n_type_gfx bx,by,bsx,bsy; n_win_rect_expand_size( &p->selection_rect, &bx,&by,&bsx,&bsy );

			u32 color = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( bg ) );

			n_bmp_box( &p->bmp_oneline, bx,by,bsx,bsy, color );
		}

		n_bmp_antialias( &bmp_fog, fx,fy,fsx,fsy, 1.0 );
		n_win_txtbox_bmp_alpha_enhancer( &bmp_fog, 0.33 );
		n_win_txtbox_bmp_alpha_reducer ( &bmp_txt, 0.10 );
		n_bmp_rasterizer_all( &bmp_fog, &p->bmp_oneline, fx,fy,fsx,fsy, fx,fy, NULL,n_bmp_rgb(  10, 10, 10 ), NULL,0,0, n_posix_false );
		n_bmp_rasterizer_all( &bmp_txt, &p->bmp_oneline, fx,fy,fsx,fsy, fx,fy, NULL,n_bmp_rgb( 255,255,255 ), NULL,0,0, n_posix_false );

		n_win_txtbox_draw_caret( p, hdc_cmpt, &p->bmp_oneline );

		n_bmp_mirror( &p->bmp_oneline, fx,fy,fsx,fsy, N_BMP_MIRROR_UPSIDE_DOWN );

		n_gdi_bitmap_draw_main( p->hwnd, hdc_main, &p->bmp_oneline, x,y,sx,sy, x,y );

		n_bmp_free_fast( &bmp_fog );
		n_bmp_free_fast( &bmp_txt );

		p->bmp_backbuffer = &p->bmp_oneline;

	} else {

		BitBlt( hdc_main, x,y,sx,sy, hdc_cmpt, x,y, SRCCOPY );

		p->bmp_backbuffer = &p->bmp;

	}


	return;
}

// internal
void
n_win_txtbox_draw_sync( n_win_txtbox *p )
{

	HDC hdc_main = GetDC( p->hwnd );
	HDC hdc_cmpt = CreateCompatibleDC( hdc_main );

	HBITMAP hbmp_old = SelectObject( hdc_cmpt, p->hbmp );

	n_win_txtbox_draw_bitblt( p, hdc_main, hdc_cmpt, 0,0,N_BMP_SX( &p->bmp ),N_BMP_SY( &p->bmp )  );

	SelectObject( hdc_cmpt, hbmp_old );

	DeleteObject( hdc_cmpt );
	ReleaseDC( p->hwnd, hdc_main );


	return;
}

#define n_win_txtbox_draw_selection( p, id ) n_win_txtbox_draw_partial( p, id, (p)->select_cch_y, (p)->select_cch_sy )
#define n_win_txtbox_draw(           p, id ) n_win_txtbox_draw_partial( p, id, N_WIN_TXTBOX_NOT_SELECTED, N_WIN_TXTBOX_NOT_SELECTED )

// internal
void
n_win_txtbox_draw_partial( n_win_txtbox *p, int id, n_type_int line_y, n_type_int line_sy )
{
if ( n_win_txtbox_debug_enabled_id( p, id ) ) { n_win_txtbox_hwndprintf_literal( p, " Draw : %d ", id ); }


	if ( p == NULL ) { return; }

	if ( n_txt_error( &p->txt ) ) { return; }


	// [!] : you need to implement this
	//
	//	because of initialization will fail

	//if ( n_posix_false == IsWindowVisible( p->hwnd ) ) { return; }


	// [!] : Metrics

	// [Needed] : ONELINE needs this
	n_win_txtbox_metrics_caret( p );


	if (1)//( p->metrics_changed )
	{
		// [!] : this module is very heavy : you need to call manually
		n_win_txtbox_metrics_canvas( p );

		// [Needed] : when resized
		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{
			n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );
		}
	}


	// [Patch] : where is an accurate place?

	if ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
	{
		//
	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_COMBOBOX_NOGRAY )
	{
		//
	} else {
		if ( p->hwnd != GetFocus() )
		{
			p->color_back_selected = p->color_sel_focus_off;
		}
	}


	SIZE halfwidth = { p->font_pxl_sx * 1, p->cell_pxl_sy };
	SIZE fullwidth = { p->font_pxl_sx * 2, p->cell_pxl_sy };

	p->size_halfwidth = halfwidth;
	p->size_fullwidth = fullwidth;


	n_type_gfx sx = p->client_pxl_sx;
	n_type_gfx sy = p->client_pxl_sy;


	// [!] : HDC

	HDC hdc_main;
	HDC hdc_cmpt;

	if ( p->hdc_printclient == NULL )
	{
		hdc_main = GetDC( p->hwnd );
	} else {
		hdc_main = p->hdc_printclient;
	}

	hdc_cmpt = CreateCompatibleDC( hdc_main );

//n_win_txtbox_draw_box( p, hdc_main, NULL, RGB( 0,200,255 ) );


	// [!] : selection

	const n_type_int nosel = N_WIN_TXTBOX_NOT_SELECTED;


	// Debug Center

	p->optimization_onoff = n_posix_true;
	p->optimization_type  = N_WIN_TXTBOX_OPTIMIZATION_NONE;
	p->optimization_sync  = N_WIN_TXTBOX_OPTIMIZATION_SYNC_NONE;

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		//p->optimization_onoff = n_posix_false;
	}

	if ( p->optimization_stop )
	{
		p->optimization_onoff = n_posix_false;
	}

	if ( p->optimization_onoff == n_posix_false )
	{
		line_y = line_sy = nosel;
	}

//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d %d ", p->drag_phase, p->drag_cch_y, p->select_cch_y, p->select_cch_sy );

	p->debug_draw_onoff = n_posix_false;

	n_posix_bool debug_output = n_posix_false;
	n_posix_bool debug_detail = n_posix_false;


	if ( p->optimization_onoff )
	{
//n_win_txtbox_hwndprintf_literal( p, " %d : %d : %d %d ", p->drag_phase, p->drag_cch_y, p->select_cch_y, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_scr_x, p->scroll_pxl_tabbed_x );

		if ( p->prv_txt_sy > p->txt.sy )
		{
//n_win_txtbox_debug_count( p );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->scroll_cch_tabbed_y, p->prv_scr_y, p->last_cch_tabbed_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->scroll_cch_tabbed_y, p->prv_txt_sy, p->txt.sy );

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_OTHERS;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

			line_y  = nosel;
			line_sy = nosel;

			n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );

		} else
		if (
			( p->prv_scr_x != p->scroll_pxl_tabbed_x )
			||
			( p->prv_scr_y != p->scroll_cch_tabbed_y )
		)
		{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_SCROLL " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_SCROLL;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

			// [!] : Slow Mode

			line_y  = nosel;
			line_sy = nosel;

			p->prv_scr_x  = p->scroll_pxl_tabbed_x;
			p->prv_scr_y  = p->scroll_cch_tabbed_y;

		} else
		if ( n_win_is_input( VK_SHIFT ) )
		{
//if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_SHIFT " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_SHIFT;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

			// [!] : Slow Mode

			line_y  = nosel;
			line_sy = nosel;

			p->caret_redraw_x  = 0;
			p->caret_redraw_sx = sx;

			// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_sel_sx, p->select_cch_sx );

			if ( n_win_is_input( VK_BACK ) )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " SHIFT : is_backspace " ); }

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

				if ( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
				{
					p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;
					p->caret_redraw_x    = p->ime.x;
				}
			} else
			if ( n_win_is_input( VK_RETURN ) )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " SHIFT : is_carrage_return " ); }

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

			} else
			if ( p->is_caret_tail )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " SHIFT : p->is_caret_tail " ); }

				p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;

				n_win_txtbox_previous_calc_selected( p, &line_y, &line_sy );

				// [x] : something is wrong
				if ( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
				{
					//p->caret_redraw_x  = p->shift_dragging_start_pxl_x;
					//p->caret_redraw_sx = p->size_fullwidth.cx * p->shift_dragging_start_x;
				}

			} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " SHIFT : Others " ); }

				n_win_txtbox_previous_calc_selected( p, &line_y, &line_sy );

				if ( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
				{
					p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;
					p->caret_redraw_x    = p->ime.x;
					if ( p->is_caret_tail == n_posix_false )
					{
						p->caret_redraw_x = 0;
					}
				}
			}

		} else
		if ( p->drag_phase == N_WIN_TXTBOX_DRAG_PHASE_STARTED )
		{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_DRAG " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_DRAG;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

/*
			// [!] : Slow Mode

			line_y  = nosel;
			line_sy = nosel;

			p->drag_cch_min = 0;
			p->drag_cch_max = p->page_cch_tabbed_sy;
*/

			// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", p->drag_cch_y, p->drag_cch_min, p->select_cch_y, p->select_cch_sy );

			if (
				( p->scroll_pxl_tabbed_x == 0 )
				&&
				( p->prv_scr_y == p->scroll_cch_tabbed_y )
			)
			{
//if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " OPTIMIZATION_DRAG : Fast : %d %d ", p->prv_scr_y, p->scroll_cch_tabbed_y ); }

				line_y  = n_posix_min_n_type_int( p->drag_cch_min, p->select_cch_y );
				line_sy = n_posix_max_n_type_int( p->drag_cch_max, abs( p->drag_cch_min - p->select_cch_y ) + p->select_cch_sy );

				p->drag_cch_min = line_y;
				p->drag_cch_max = line_sy;

if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " OPTIMIZATION_DRAG : Fast : %d %d ", p->drag_cch_min, p->drag_cch_max ); }
			} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " OPTIMIZATION_DRAG : Slow : %d %d ", p->prv_scr_y, p->scroll_cch_tabbed_y ); }

				line_y  = nosel;
				line_sy = nosel;

				p->drag_cch_min = 0;
				p->drag_cch_max = p->page_cch_tabbed_sy;
			}

			p->prv_scr_x  = p->scroll_pxl_tabbed_x;
			p->prv_scr_y  = p->scroll_cch_tabbed_y;

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", line_y, line_sy, p->drag_cch_min, p->drag_cch_max );
//line_y = line_sy = nosel;

		} else
		if ( p->typing_only )
		{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_TYPING " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_TYPING;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", p->prv_sel_y, p->select_cch_y, p->prv_sel_sy, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->vk_key, p->is_backspace, p->is_carrage_return );

			if ( p->is_backspace )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_backspace " ); }

				// [!] : Slow Mode

				//line_y  = nosel;
				//line_sy = nosel;


				// [!] : Fast Mode

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

			} else
			if ( p->is_carrage_return )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_carrage_return " ); }

				// [!] : Slow Mode

				//line_y  = nosel;
				//line_sy = nosel;


				// [!] : Fast Mode

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

			} else
			if ( p->is_ud )
			{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP or VK_DOWN " ); }

				p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d ", p->select_cch_y, p->select_cch_sy, p->prv_sel_y );

				// [!] : Slow Mode

				line_y  = nosel;
				line_sy = nosel;

				p->caret_redraw_x  = 0;
				p->caret_redraw_sx = sx;

				if ( p->prv_scr_y != p->scroll_cch_tabbed_y )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP or VK_DOWN : Scrolled " ); }

					//
				} else
				if ( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP or VK_DOWN : Fast Mode " ); }

					line_y  = n_posix_min_n_type_int( p->prv_sel_y, p->select_cch_y );
					line_sy = 2;

					p->caret_redraw_x  = 0;
					p->caret_redraw_sx = sx;

					//p->caret_redraw_x  = p->ime.x;
					//p->caret_redraw_sx = p->caret_pxl_sx + 1;

					if ( p->vk_key == VK_UP )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : %d %d ", line_y, line_sy ); }

					} else
					if ( p->vk_key == VK_DOWN )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : %d %d ", line_y, line_sy ); }
					}

				}

//line_y  = 0;
//line_sy = 1;

			} else
			if ( p->is_lr )
			{
//if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr " ); }

				p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;

//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d ", p->vk_key, line_y, line_sy );

				if ( p->prv_scr_x != p->scroll_pxl_tabbed_x )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr : Scroll X " ); }

					line_y  = nosel;
					line_sy = nosel;

				} else
				if ( p->prv_scr_y != p->scroll_cch_tabbed_y )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr : Scroll Y " ); }

					line_y  = nosel;
					line_sy = nosel;

				} else {

					if ( line_sy == 1 )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr : ( line_sy == 1 ) " ); }

						if ( p->is_lr == VK_LEFT )
						{
							p->caret_redraw_x  = p->ime.x - p->size_fullwidth.cx;
							p->caret_redraw_sx = p->size_fullwidth.cx * 2;
						} else
						if ( p->is_lr == VK_RIGHT )
						{
							p->caret_redraw_x  = p->ime.x;
							p->caret_redraw_sx = p->size_fullwidth.cx * 2;
						}
					} else {

						p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_OTHERS;
						p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

						// [!] : Slow Mode

						//line_y  = nosel;
						//line_sy = nosel;

						p->caret_redraw_x  = 0;
						p->caret_redraw_sx = sx;

						// [!] : Fast Mode

						line_y  = n_posix_min_n_type_int( p->prv_sel_y, p->select_cch_y );
						line_sy = 2;

						p->is_lr = 0;

if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " is_lr : between lines : %d %d : %d %d ", p->prv_sel_y, p->select_cch_y, line_y, line_sy ); }
					}

				}

			} else {

				p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_OTHERS;
				p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL;

				// [!] : Slow Mode

				//line_y  = nosel;
				//line_sy = nosel;

				p->caret_redraw_x  = 0;
				p->caret_redraw_sx = sx;

				// [!] : Fast Mode

				n_win_txtbox_previous_calc( p, &line_y, &line_sy );

if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " TYPING : Others : ID %d : %d %d ", id, line_y, line_sy ); }
			}

//n_win_txtbox_hwndprintf_literal( p, " %d/%d %d/%d  ", p->prv_scr_x, p->scroll_pxl_tabbed_x, p->prv_scr_y, p->scroll_cch_tabbed_y );

			p->prv_scr_x  = p->scroll_pxl_tabbed_x;
			p->prv_scr_y  = p->scroll_cch_tabbed_y;

			n_win_txtbox_previous( p );

//n_win_txtbox_hwndprintf_literal( p, " %d  ", p->vk_key );
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d ", p->is_carrage_return, line_y, line_sy );
		} else
		if ( p->optimization_click_onoff )
		{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " N_WIN_TXTBOX_OPTIMIZATION_CLICK " ); }

			p->optimization_type = N_WIN_TXTBOX_OPTIMIZATION_CLICK;
			p->optimization_sync = N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART;

			// [x] : conflict with .empty_line_selection on/off

			//p->caret_redraw_x  = p->ime.x;
			//p->caret_redraw_sx = p->size_fullwidth.cx * 2;

			{
				p->caret_redraw_x  = 0;
				p->caret_redraw_sx = sx;
			}
		} else {

if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " Others : ID %d : %d %d ", id, line_y, line_sy ); }

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", p->partial_selection_from_onoff, p->partial_selection_to___onoff, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

		}

	} else {

if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " p->optimization_onoff : false : %d %d ", line_y, line_sy ); }

	}

	n_posix_bool is_partial = n_posix_false;

	if ( p->optimization_onoff )
	{
		is_partial = ( line_y != nosel );
	}

	if ( line_y  == nosel ) { line_y  = p->scroll_cch_tabbed_y ; }
	if ( line_sy == nosel ) { line_sy = p->  page_cch_tabbed_sy; }

	line_y  = n_posix_max( line_y , p->scroll_cch_tabbed_y  );
	line_sy = n_posix_min( line_sy, p->  page_cch_tabbed_sy );


	// [!] : back buffer

	n_type_gfx back_buffer_sx = sx + p->shadow_size;
	n_type_gfx back_buffer_sy = sy + p->shadow_size;

	if (
		( p->metrics_changed ) 
		||
		( ( p->client_prv_sx != back_buffer_sx )||( p->client_prv_sy != back_buffer_sy ) )
		||
		( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	)
	{

		p->metrics_changed = n_posix_false;


		n_gdi_dibsection_exit( &p->hbmp, &p->bmp );
		n_gdi_dibsection_init( &p->hbmp, &p->bmp, p->hwnd, hdc_cmpt, back_buffer_sx,back_buffer_sy );
/*
		if ( NULL != N_BMP_PTR( &p->bmp ) )
		{
			n_bmp_flush( &p->bmp, n_bmp_rgb( 0,200,255 ) );
		}
*/
		p->client_prv_sx = back_buffer_sx;
		p->client_prv_sy = back_buffer_sy;


		n_bmp_free( &p->bmp_roundfr );

	}
//n_bmp_save_literal( &p->bmp, "ret.bmp" );

	HBITMAP hbmp_old = SelectObject( hdc_cmpt, p->hbmp );


	// [!] : draw

	n_posix_bool debug_stop = n_posix_false;


	n_type_gfx nx = p->border_pxl_sx + p->pad_pxl_sx;
	n_type_gfx ny = p->border_pxl_sy + p->pad_pxl_sy;

	n_type_int redraw_y  = 0;
	n_type_int redraw_sy = 0;


	{ // Text Lockdown

	n_type_gfx ox = (           p->scroll_pxl_tabbed_x );
	n_type_gfx oy = ( line_y  - p->scroll_cch_tabbed_y ) * p->cell_pxl_sy;

	n_type_gfx  x = nx + ox;
	n_type_gfx  y = ny + oy;

	// [Needed] : ONELINE patch : "y" needs to move to upper

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		y = abs( p->client_pxl_sy - p->cell_pxl_sy ) / 2;
	}

	redraw_y  = y;
	redraw_sy = p->cell_pxl_sy;

	if ( p->optimization_onoff )
	{

		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_NONE )
		{
			//
		} else
		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL  )
		{
			redraw_sy += p->cell_pxl_sy * ( line_sy - 1 );
		} else
		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART )
		{
			redraw_sy += p->cell_pxl_sy * ( line_sy - 1 );
		}

	}

	if ( debug_stop )
	{
		//
	} else
	//
	{

		// [!] : for animation
		y -= p->combo_popup_slide_pxl_sy;

		n_type_int text_fy = line_y;
		n_type_int text_ty = line_y + line_sy;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", text_fy, text_ty );

		// Debug Center
		//text_fy = 10;
		//text_ty = 20;

		HFONT hf_old = SelectObject( hdc_cmpt, n_win_font_get( p->hwnd ) );

		while( 1 )
		{//break;
//n_win_txtbox_debug_count( p );

			n_win_txtbox_draw_singleline( p, hdc_cmpt, text_fy, x, y, sx, p->cell_pxl_sy );

			//ExcludeClipRect( hdc_cmpt, x, y, x + sx, y + p->cell_pxl_sy );

			if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			{
				text_fy++;
				if ( text_fy >= text_ty ) { break; }
			} else {
				text_fy++;
				if ( text_fy > text_ty )
				{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );

					// [Patch] : when condition is bad then caret will disappear

					if ( line_y == 0 )
					{
						y += p->cell_pxl_sy;

						n_win_txtbox_draw_singleline( p, hdc_cmpt, text_fy, x, y, sx, p->cell_pxl_sy );
						//ExcludeClipRect( hdc_cmpt, x, y, x + sx, y + p->cell_pxl_sy );
					}

					break;
				}
			}

			y += p->cell_pxl_sy;
			if ( y >= sy )
			{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
				break;
			}

		}

		SelectObject( hdc_cmpt, hf_old );

		if (
			( p->select_cch_y >= ( p->scroll_cch_tabbed_y                         ) )
			&&
			( p->select_cch_y <= ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) )
		)
		{
//n_win_txtbox_hwndprintf_literal( p, "   visible " );
		} else {
//n_win_txtbox_hwndprintf_literal( p, " invisible " );
			n_win_rect_set( &p->highlight_rect, -1,-1,-1,-1 );
		}

	}


	} // Text Lockdown



	if ( debug_stop )
	{
		//
	} else
	if (
		( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		&&
		( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	)
	{

		// [!] : blank at bottom-right corner

		n_type_gfx  tsx = p->scrollbar_pxl_sx;
		n_type_gfx  tsy = p->scrollbar_pxl_sy;
		n_type_gfx   tx = p->client_pxl_sx - p->scrollbar_pxl_sx - p->border_pxl_sx;
		n_type_gfx   ty = p->client_pxl_sy - p->scrollbar_pxl_sy - p->border_pxl_sy;
		RECT   r = n_win_rect_set( NULL, tx, ty, tsx, tsy );

		if ( p->debug_onoff )
		{
			n_bmp_mixer( p->debug_bmp, tx, ty, tsx, tsy, p->color_base__padding, 0.5 );
		} else {
			n_win_txtbox_draw_box( p, hdc_cmpt, &r, p->color_base__padding );
		}

		ExcludeClipRect( hdc_cmpt, r.left, r.top, r.right, r.bottom );

	}


	// [!] : padding

	if ( debug_stop )
	{
		//
	} else
	if ( p->aero_combo_onoff )
	{
		//
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
	{
		//
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		//
	} else {
		COLORREF color_padding = p->color_back_noselect;
		if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG ) { color_padding = 0; }

		n_type_gfx ncx, ncy;

		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{
			n_type_gfx scr_sx = 0;
			n_type_gfx scr_sy = 0;

			if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { scr_sx = p->scrollbar_pxl_sx; }
			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { scr_sy = p->scrollbar_pxl_sy; }

			ncx = scr_sx + ( ( p->border_pxl_sx + p->pad_pxl_sx ) * 2 );
			ncy = scr_sy + ( ( p->border_pxl_sy + p->pad_pxl_sy ) * 2 );

			ExcludeClipRect( hdc_cmpt, nx, ny, nx + sx - ncx, ny + sy - ncy );
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			ncx = ( p->border_pxl_sx + p->pad_pxl_sx ) * 2;
			ncy = ( p->border_pxl_sy + p->pad_pxl_sy ) * 2;

			if ( n_win_style_is_classic() )
			{
				ncy -= 2;
			} else {
				ny  -= 1;
				ncy -= 4;
			}

			ExcludeClipRect( hdc_cmpt, nx, ny, nx + sx - ncx, ny + sy - ncy );
		} else {
//n_win_txtbox_debug_count( p );

			n_type_gfx scr_sx = 0;
			n_type_gfx scr_sy = 0;

			if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { scr_sx = p->scrollbar_pxl_sx; }
			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { scr_sy = p->scrollbar_pxl_sy; }

			ncx = scr_sx + ( ( p->border_pxl_sx + p->pad_pxl_sx ) * 2 );
			ncy = scr_sy + ( ( p->border_pxl_sy + p->pad_pxl_sy ) * 2 );

			ExcludeClipRect( hdc_cmpt, nx, ny, nx + sx - ncx, ny + sy - ncy );
		}


		if ( n_win_fluent_ui_onoff )
		{
			if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			{
				//
			} else {
				RECT rect; n_win_rect_set( &rect, 0,0,p->client_pxl_sx,p->client_pxl_sy );
				n_win_box( p->hwnd, hdc_cmpt, &rect, color_padding );
			}
		} else {
			RECT rect; n_win_rect_set( &rect, 0,0,p->client_pxl_sx,p->client_pxl_sy );
			n_win_box( p->hwnd, hdc_cmpt, &rect, color_padding );
		}

		// [Needed] : left side padding : when scrolled

		if ( p->scroll_pxl_tabbed_x != 0 )
		{
			RECT rect; n_win_rect_set( &rect, 0, p->border_pxl_sy, p->border_pxl_sx + p->pad_pxl_sx, p->client_pxl_sy );
			n_win_box( p->hwnd, hdc_cmpt, &rect, color_padding );
		}

	}


	// [!] : border

	if ( debug_stop )
	{
		//
	} else {
		n_win_txtbox_draw_frame( p, hdc_cmpt, n_posix_true );
//n_bmp_save_literal( &p->bmp, "ret.bmp" );
	}


	// [!] : small buttons

	int i = 0;
	while( debug_stop == n_posix_false )
	{//break;

		n_win_smallbutton_direct *sb = p->smallbutton[ i ];

		if ( sb != NULL )
		{
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", sb->x, sb->y, sb->sx, sb->sy );

			// [Needed] : CatPad : input field resizer
			n_win_txtbox_smallbutton_direct_rearrange( p, sb, i );

			n_win_smallbutton_direct_bitmap_draw( sb );
		}

		i++;
		if ( i >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) { break; }
	}


	// [!] : round corner

	//if ( p->bitblt_stop == n_posix_false )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
		{
//n_win_txtbox_hwndprintf_literal( p, "STYLE_VISIBLE" );

			//n_bmp_alpha_visible( &p->bmp );

			n_win_txtbox_draw_alpha_visible( p, 0, 0, p->client_pxl_sx, p->client_pxl_sy );
		}

		if ( debug_stop )
		{
			//
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
		{
			//
		} else
		if (
			( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
			||
			( p->style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
		)
		{
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", x, y, sx, sy );

			if ( p->style_option & N_WIN_TXTBOX_OPTION_PARENT_BACKGRND )
			{
				u32 color = 0;
				n_win_txtbox_bmp_cornermask( p, 0, 0, p->client_pxl_sx, p->client_pxl_sy, color );
			} else
			if ( id == N_WIN_TXTBOX_PROC_WM_DRAWITEM )
			{
				u32 color = n_win_cornercolor_get( p->hwnd );
				n_win_txtbox_bmp_cornermask( p, 0, 0, p->client_pxl_sx, p->client_pxl_sy, color );
			}
		}

	}


	// [!] : sync

	if ( p->bitblt_stop == n_posix_false )
	{

		n_type_gfx tx  = 0;
		n_type_gfx ty  = 0;
		n_type_gfx tsx = sx + p->shadow_size;
		n_type_gfx tsy = sy + p->shadow_size;

		if ( p->optimization_onoff )
		{

			if ( is_partial )
			{
				ty  = redraw_y;
				tsy = redraw_sy;
			}

			if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL  )
			{
				//
			} else
			if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART )
			{
				tx  = n_posix_max_n_type_gfx( p->caret_redraw_x , p->border_pxl_sx );
				tsx = n_posix_min_n_type_gfx( p->caret_redraw_sx, p->client_pxl_sx - ( p->border_pxl_sx * 2 ) );
			}

		}

		n_win_txtbox_draw_bitblt( p, hdc_main, hdc_cmpt, tx,ty,tsx,tsy );

	}


	SelectObject( hdc_cmpt, hbmp_old );


	// [Needed] : after drawn

	if ( debug_stop )
	{
		//
	} else {
		n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );
		n_win_txtbox_draw_scrollbars( p );
	}


	// [!] : cleanup

	DeleteObject( hdc_cmpt );

	if ( p->hdc_printclient == NULL )
	{
		ReleaseDC( p->hwnd, hdc_main );
	}

	p->is_backspace = p->is_carrage_return = n_posix_false;


	return;
}


