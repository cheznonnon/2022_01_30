// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_CALENDAR
#define _H_NONNON_WIN32_WIN_CALENDAR




#include "./gdi/doublebuffer_32bpp.c"
#include "./win.c"
#include "./win_scroll.c"




#define N_WIN_CALENDAR_INSTANCE n_posix_literal( "Nonnon.Win32.Calendar" )




typedef struct {

	HWND     hgui;
	WNDPROC pfunc;

	int     year, month, day;

} n_win_calendar;


static n_posix_bool n_win_calendar_printclient_onoff = n_posix_false;




// internal
HFONT
n_win_calendar_font( HWND hgui, LONG size, n_posix_bool bold )
{

	// [Needed] : n_win_font_exit( hfont );


	LOGFONT lf = n_win_font_hwnd2logfont( hgui );

	lf.lfHeight = n_posix_min( lf.lfHeight, size );

	if ( bold ) { lf.lfWeight = FW_BOLD; }


	return n_win_font_logfont2hfont( &lf );
}

// internal
void
n_win_calendar_draw( HWND hgui, HDC hdc_override, RECT *rect_override, int year, int month, int day )
{

	RECT rect;
	if ( rect_override == NULL )
	{
		GetClientRect( hgui, &rect );
	} else {
		rect = (*rect_override); 
	}


	const n_type_gfx divx = 7;
	const n_type_gfx divy = 1 + 6;

	const n_type_gfx  x = rect.left;
	const n_type_gfx  y = rect.top;
	const n_type_gfx sx = rect.right  - x;
	const n_type_gfx sy = rect.bottom - y;

	const n_type_gfx cellsx = sx / divx;
	const n_type_gfx cellsy = sy / divy;
	const n_type_gfx fontsy = cellsy;

	if ( cellsx <= 0 ) { return; }
	if ( cellsy <= 0 ) { return; }


	// [x] : flicker prevention : n_gdi_doublebuffer_32bpp_simple_init() only

	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( hgui, sx,sy );

	n_bmp *bmp =& n_gdi_doublebuffer_32bpp_instance.bmp;

	SetBkMode( hdc, TRANSPARENT );


	// Clamp

	year  = n_posix_max( 1900, year );
	month = n_posix_minmax( 1, 12, month );


	// Colors

	COLORREF color_bg          = n_win_darkmode_systemcolor_ui( COLOR_WINDOW        );
	COLORREF color_text_normal = n_win_darkmode_systemcolor_ui( COLOR_WINDOWTEXT    );
	//COLORREF color_back_hilite = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT     );
	COLORREF color_text_hilite = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHTTEXT );
	COLORREF color_text_grayed = n_win_darkmode_systemcolor_ui( COLOR_GRAYTEXT      );

	u32      color_argb_hilite = n_win_dwm_windowcolor_arranged();
	u32      color_argb_backgd = n_win_darkmode_systemcolor_colorref2argb( COLOR_WINDOW    );
	u32      color_argb_backhl = n_win_darkmode_systemcolor_colorref2argb( COLOR_HIGHLIGHT );


	// Erase Background

	n_type_gfx round = 0;
	n_type_gfx frame = 0;

	if ( n_win_fluent_ui_onoff )
	{
		round = n_win_fluent_ui_round_param( hgui );
		frame = (n_type_gfx) trunc( n_win_scale( hgui ) );

		u32 fg = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color_text_grayed ) );
		u32 bg = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color_bg          ) );

		n_bmp_ui_roundframe( bmp, 0,0,sx,sy, round, frame, fg, bg );
	} else {
		n_bmp_box( bmp, 0,0,sx,sy, color_argb_backgd );
	}


//n_gdi_doublebuffer_simple_exit(); return;


	// Header

	{

		RECT  r  = { x,y, x+sx, y+cellsy };
		HFONT hf = SelectObject( hdc, n_win_calendar_font( hgui, fontsy, n_posix_true ) );
		int   dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );


		u32 hilite = color_argb_hilite;
		n_bmp_box( bmp, x,y, x+sx, y+cellsy, hilite );


		n_posix_char str[ 100 ];
		n_posix_sprintf_literal( str, "%4d %02d", year, month );

		SetTextColor( hdc, color_text_hilite );

		DrawText( hdc, str,-1, &r, dt );


		n_win_font_exit( SelectObject( hdc, hf ) );

	}
//n_gdi_doublebuffer_simple_exit(); return;


	// Calendar

	{

		RECT     r;
		HFONT    hf = SelectObject( hdc, n_win_calendar_font( hgui, fontsy, n_posix_false ) );
		int      dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
		COLORREF fg, bg;

		n_posix_char str[ 10 ];

		int first = n_time_dayofweek( year, month );
		int last  = n_time_lastday  ( year, month );

		int today_year, today_month;
		n_time_today( &today_year, &today_month, NULL, NULL, NULL, NULL );

//n_win_hwndprintf_literal( GetParent( hgui ), "%d : %d", first, last );


		// [!] : don't do size-based approach : modulo handling is hard

		n_type_gfx cx = 0;
		n_type_gfx cy = 0;
		n_type_gfx ox = ( ( sx % divx ) / 2 );
		n_type_gfx oy = ( ( sy % divy ) / 2 ) + cellsy;

		int i = 0;
		while( 1 )
		{

			r.left    = ox + x + ( cellsx * cx );
			r.top     = oy + y + ( cellsy * cy );
			r.right   = r.left + cellsx;
			r.bottom  = r.top  + cellsy;


			fg = color_text_normal;
			bg = color_bg;


			int today = ( i - first ) + 1;

			if ( ( today >= 1 )&&( today <= last ) ) 
			{

				if ( ( today_year == year )&&( today_month == month )&&( today == day ) )
				{

					n_win_rect_resize( &r, -2,-2 );

					n_type_gfx xx,yy,sxx,syy; n_win_rect_expand_size( &r, &xx, &yy, &sxx, &syy );

					if ( n_win_fluent_ui_onoff )
					{
						n_bmp_circle( bmp, xx,yy,sxx,syy, sxx, color_argb_hilite );
					} else {
						n_bmp_box   ( bmp, xx,yy,sxx,syy,      color_argb_backhl );
					}

					fg = color_text_hilite;

				} else
				if ( today == day )
				{

					n_win_rect_resize( &r, -2,-2 );

					u32 color = n_bmp_blend_pixel( color_argb_backgd, color_argb_hilite, 0.5 );

					n_type_gfx xx,yy,sxx,syy; n_win_rect_expand_size( &r, &xx, &yy, &sxx, &syy );

					if ( n_win_fluent_ui_onoff )
					{
						n_bmp_circle( bmp, xx,yy,sxx,syy, sxx, color );
					} else {
						n_bmp_box   ( bmp, xx,yy,sxx,syy,      color );
					}

					fg = color_text_hilite;

				}

			} else
			if ( today > last )
			{

				today -= last;

				fg = color_text_grayed;

			} else
			if ( today <= 0 )
			{

				int y = year;
				int m = month - 1;

				if ( m == 0 ) { y--; m = 12; }

				today = n_time_lastday( y, m ) + today;

				fg = color_text_grayed;

			}


			n_posix_sprintf_literal( str, "%d", today );

			SetTextColor( hdc, fg );

			DrawText( hdc, str,-1, &r, dt );


			i++;

			cx++;
			if ( cx >= divx )
			{

				cx = 0;

				cy++;
				if ( cy >= divy ) { break; }
			}
		}

		n_win_font_exit( SelectObject( hdc, hf ) );

	}


	if ( hdc_override == NULL )
	{
		n_gdi_doublebuffer_32bpp_simple_exit();
	} else {
		BitBlt( hdc_override, 0,0,sx,sy, hdc, 0,0, SRCCOPY );
		n_gdi_doublebuffer_32bpp_simple_cleanup();
	}


	return;
}

void
n_win_calendar_init( n_win_calendar *p, HWND hwnd_parent )
{

	if ( p == NULL ) { return; }


	n_win_gui_literal( hwnd_parent, N_WIN_GUI_CANVAS, "", &p->hgui );


	n_win_stdfont_init( &p->hgui, 1 );


	n_time_today( &p->year, &p->month, &p->day, NULL, NULL, NULL );


	return;
}

void
n_win_calendar_exit( n_win_calendar *p, HWND hwnd_parent )
{

	if ( p == NULL ) { return; }


	n_win_stdfont_exit( &p->hgui, 1 );


	DestroyWindow( p->hgui );


	return;
}

void
n_win_calendar_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_calendar *p )
{

	switch( msg ) {


	case WM_TIMECHANGE :

		n_time_today( &p->year, &p->month, &p->day, NULL, NULL, NULL );
		n_win_refresh( p->hgui, n_posix_false );

	break;


	case WM_SIZE :
	{

		if ( n_posix_false == IsWindow( p->hgui ) ) { break; }

		n_win_refresh( p->hgui, n_posix_false );

	}
	break;


	case WM_PRINTCLIENT :
	{
		if ( n_win_calendar_printclient_onoff == n_posix_false ) { break; }

		RECT rect; GetWindowRect( p->hgui, &rect );

		POINT pt_lt = { rect.left , rect.top    };
		POINT pt_rb = { rect.right, rect.bottom };

		ScreenToClient( hwnd, &pt_lt );
		ScreenToClient( hwnd, &pt_rb );

		RECT r = { pt_lt.x, pt_lt.y, pt_rb.x, pt_rb.y };

		n_win_calendar_draw( p->hgui, (HDC) wparam, &r, p->year, p->month, p->day );
	}
	break;

	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( p->hgui != di->hwndItem ) { break; }

		n_win_calendar_draw( p->hgui, NULL, &di->rcItem, p->year, p->month, p->day );

	}
	break;


	case WM_LBUTTONDBLCLK :

		if ( n_win_is_hovered( p->hgui ) )
		{
			n_time_today( &p->year, &p->month, &p->day, NULL, NULL, NULL );
			n_win_refresh( p->hgui, n_posix_false );
		}

	break;


	case WM_MOUSEWHEEL :

		if ( n_win_is_hovered( p->hgui ) )
		{

			int delta = n_win_scroll_wheeldelta( wparam, 1 );

			if ( delta == 0 ) { break; }

			p->month += delta;
			if ( p->month <  1 ) { p->year--; p->month = 12; } else
			if ( p->month > 12 ) { p->year++; p->month =  1; }


			n_win_refresh( p->hgui, n_posix_false );

		}

	break;

	case WM_KEYDOWN :

		if ( n_win_is_hovered( p->hgui ) )
		{

			if ( wparam == VK_UP )
			{
				p->year = n_posix_max( 1900, p->year - 1 );
			} else
			if ( wparam == VK_DOWN )
			{
				p->year = n_posix_min( 9999, p->year + 1 );
			} else
			if ( wparam == VK_LEFT )
			{
				p->month--; if ( p->month <  1 ) { p->year--; p->month = 12; }
			} else
			if ( wparam == VK_RIGHT )
			{
				p->month++; if ( p->month > 12 ) { p->year++; p->month =  1; }
			} else
			//
			{
				break;
			}

			n_win_refresh( p->hgui, n_posix_false );

		}

	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_CALENDAR


/*


#include "./win.c"


#include "../project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_calendar h_calendar[ 2 ];


	switch( msg ) {


	case WM_CREATE :

		// Global

		n_project_darkmode()
		//n_win_darkmode_onoff = n_posix_true;


		// Window

		n_win_init_literal( hwnd, "Nonnon Calendar Test", "", "" );


		n_win_calendar_init( &h_calendar[ 0 ], hwnd );
		n_win_calendar_init( &h_calendar[ 1 ], hwnd );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// Size

		n_win_set( hwnd, NULL, 256*2,256, N_WIN_SET_CENTERING );
		WndProc( hwnd, WM_SIZE, 0,0 );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_DEFAULT );

		n_type_gfx sx = w.csx / 2;
		n_type_gfx sy = w.csy;

		n_win_move( h_calendar[ 0 ].hgui,  0,0, sx,sy, n_posix_true );
		n_win_move( h_calendar[ 1 ].hgui, sx,0, sx,sy, n_posix_true );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_calendar_exit( &h_calendar[ 0 ], hwnd );
		n_win_calendar_exit( &h_calendar[ 1 ], hwnd );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_calendar_proc( hwnd,msg,wparam,lparam, &h_calendar[ 0 ] );
	n_win_calendar_proc( hwnd,msg,wparam,lparam, &h_calendar[ 1 ] );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


*/


