// Windows Imaging Component Support
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Limitaiton ]
//
//	+ WinXP SP2 or later only
//	+ decoder only
//	+ webp plugin : Win10 or later only
//
//	+ 32-bit version : almost implementation is stub




#ifndef _H_NONNON_WIN32_WIC
#define _H_NONNON_WIN32_WIC




#include "../neutral/bmp/all.c"




#ifdef _MSC_VER


#include <wincodec.h>

#pragma comment( lib, "Windowscodecs.lib" )


#else  // #ifdef _MSC_VER


//#define IWICImagingFactory    IUnknown
//#define IWICBitmapDecoder     IUnknown
//#define IWICFormatConverter   IUnknown
//#define IWICBitmapFrameDecode IUnknown


const GUID CLSID_WICImagingFactory       = { 0xcacaf262,0x9370,0x4615,{ 0xa1,0x3b, 0x9f,0x55,0x39,0xda,0x4c,0x0a } };
const GUID  IID_IWICImagingFactory       = { 0xec5ec8a9,0xc395,0x4314,{ 0x9c,0x77, 0x54,0xd7,0xa9,0x35,0xff,0x70 } };
const GUID GUID_WICPixelFormat32bppPBGRA = { 0x6fddc324,0x4e03,0x4bfe,{ 0xb1,0x85, 0x3d,0x77,0x76,0x8d,0xc9,0x10 } };


typedef GUID    WICPixelFormatGUID;
typedef REFGUID REFWICPixelFormatGUID;

typedef struct WICRect {

	INT X;
	INT Y;
	INT Width;
	INT Height;

} WICRect;


enum WICDecodeOptions {

	WICDecodeMetadataCacheOnDemand     = 0,
	WICDecodeMetadataCacheOnLoad       = 0x1,
	WICMETADATACACHEOPTION_FORCE_DWORD = 0x7fffffff

} WICDecodeOptions;


enum WICBitmapDitherType {

	WICBitmapDitherTypeNone	          = 0,
	WICBitmapDitherTypeSolid          = 0,
	WICBitmapDitherTypeOrdered4x4     = 0x1,
	WICBitmapDitherTypeOrdered8x8     = 0x2,
	WICBitmapDitherTypeOrdered16x16   = 0x3,
	WICBitmapDitherTypeSpiral4x4      = 0x4,
	WICBitmapDitherTypeSpiral8x8      = 0x5,
	WICBitmapDitherTypeDualSpiral4x4  = 0x6,
	WICBitmapDitherTypeDualSpiral8x8  = 0x7,
	WICBitmapDitherTypeErrorDiffusion = 0x8,
	WICBITMAPDITHERTYPE_FORCE_DWORD	  = 0x7fffffff

} WICBitmapDitherType;


enum WICBitmapPaletteType {

	WICBitmapPaletteTypeCustom           = 0,
	WICBitmapPaletteTypeMedianCut        = 0x1,
	WICBitmapPaletteTypeFixedBW          = 0x2,
	WICBitmapPaletteTypeFixedHalftone8   = 0x3,
	WICBitmapPaletteTypeFixedHalftone27  = 0x4,
	WICBitmapPaletteTypeFixedHalftone64  = 0x5,
	WICBitmapPaletteTypeFixedHalftone125 = 0x6,
	WICBitmapPaletteTypeFixedHalftone216 = 0x7,
	WICBitmapPaletteTypeFixedWebPalette  = WICBitmapPaletteTypeFixedHalftone216,
	WICBitmapPaletteTypeFixedHalftone252 = 0x8,
	WICBitmapPaletteTypeFixedHalftone256 = 0x9,
	WICBitmapPaletteTypeFixedGray4       = 0xa,
	WICBitmapPaletteTypeFixedGray16      = 0xb,
	WICBitmapPaletteTypeFixedGray256     = 0xc,
	WICBITMAPPALETTETYPE_FORCE_DWORD     = 0x7fffffff

} WICBitmapPaletteType;


EXTERN_C const IID IID_IWICImagingFactory;
#define INTERFACE IWICImagingFactory
DECLARE_INTERFACE_( IWICImagingFactory, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( CreateDecoderFromFilename )( THIS_ LPCWSTR, const GUID*, DWORD, DWORD, void** ) PURE; // [!] : done
	STDMETHOD( CreateDecoderFromStream )( THIS ) PURE;
	STDMETHOD( CreateDecoderFromFileHandle )( THIS ) PURE;
	STDMETHOD( CreateComponentInfo )( THIS ) PURE;
	STDMETHOD( CreateDecoder )( THIS ) PURE;
	STDMETHOD( CreateEncoder )( THIS ) PURE;
	STDMETHOD( CreatePalette )( THIS ) PURE;
	STDMETHOD( CreateFormatConverter )( THIS_ void** ) PURE; // [!] : done
	STDMETHOD( CreateBitmapScaler )( THIS ) PURE;
	STDMETHOD( CreateBitmapClipper )( THIS ) PURE;
	STDMETHOD( CreateBitmapFlipRotator )( THIS ) PURE;
	STDMETHOD( CreateStream )( THIS ) PURE;
	STDMETHOD( CreateColorContext )( THIS ) PURE;
	STDMETHOD( CreateColorTransformer )( THIS ) PURE;
	STDMETHOD( CreateBitmap )( THIS ) PURE;
	STDMETHOD( CreateBitmapFromSource )( THIS ) PURE;
	STDMETHOD( CreateBitmapFromSourceRect )( THIS ) PURE;
	STDMETHOD( CreateBitmapFromMemory )( THIS ) PURE;
	STDMETHOD( CreateBitmapFromHBITMAP )( THIS ) PURE;
	STDMETHOD( CreateBitmapFromHICON )( THIS ) PURE;
	STDMETHOD( CreateComponentEnumerator )( THIS ) PURE;
	STDMETHOD( CreateFastMetadataEncoderFromDecoder )( THIS ) PURE;
	STDMETHOD( CreateFastMetadataEncoderFromFrameDecode )( THIS ) PURE;
	STDMETHOD( CreateQueryWriter )( THIS ) PURE;
	STDMETHOD( CreateQueryWriterFromReader )( THIS ) PURE;
};
#undef INTERFACE


EXTERN_C const IID IID_IWICBitmapDecoder;
#define INTERFACE IWICBitmapDecoder
DECLARE_INTERFACE_( IWICBitmapDecoder, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( QueryCapability )( THIS ) PURE;
	STDMETHOD( Initialize )( THIS ) PURE;
	STDMETHOD( GetContainerFormat )( THIS ) PURE;
	STDMETHOD( GetDecoderInfo )( THIS ) PURE;
	STDMETHOD( CopyPalette )( THIS ) PURE;
	STDMETHOD( GetMetadataQueryReader )( THIS ) PURE;
	STDMETHOD( GetPreview )( THIS ) PURE;
	STDMETHOD( GetColorContexts )( THIS ) PURE;
	STDMETHOD( GetThumbnail )( THIS ) PURE;
	STDMETHOD( GetFrameCount )( THIS_ UINT* ) PURE; // [!] : done
	STDMETHOD( GetFrame )( THIS_ UINT, void** ) PURE; // [!] : done
};
#undef INTERFACE


EXTERN_C const IID IID_IWICFormatConverter;
#define INTERFACE IWICFormatConverter
DECLARE_INTERFACE_( IWICFormatConverter, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( GetSize )( THIS ) PURE;
	STDMETHOD( GetPixelFormat )( THIS ) PURE;
	STDMETHOD( GetResolution )( THIS ) PURE;
	STDMETHOD( CopyPalette )( THIS ) PURE;
	STDMETHOD( CopyPixels )( THIS_ WICRect*, UINT, UINT, BYTE* ) PURE; // [!] : done
	STDMETHOD( Initialize )( THIS_ void*, REFWICPixelFormatGUID, DWORD, void*, double, DWORD ) PURE; // [!] : done
	STDMETHOD( CanConvert )( THIS ) PURE;
};
#undef INTERFACE


EXTERN_C const IID IID_IWICBitmapFrameDecode;
#define INTERFACE IWICBitmapFrameDecode
DECLARE_INTERFACE_( IWICBitmapFrameDecode, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( GetSize )( THIS_ UINT*, UINT* ) PURE; // [!] : done
	STDMETHOD( GetPixelFormat )( THIS_ void* ) PURE; // [!] : done
	STDMETHOD( GetResolution )( THIS ) PURE;
	STDMETHOD( CopyPalette )( THIS ) PURE;
	STDMETHOD( CopyPixels )( THIS ) PURE;
	STDMETHOD( GetMetadataQueryReader )( THIS ) PURE;
	STDMETHOD( GetColorContexts )( THIS ) PURE;
	STDMETHOD( GetThumbnail )( THIS ) PURE;
};
#undef INTERFACE


#endif // #ifdef _MSC_VER




n_posix_bool
n_wic_load( const n_posix_char *name, n_bmp *bmp )
{

	n_posix_bool ret = n_posix_true;


	if ( n_posix_false == n_posix_stat_is_file( name ) ) { return ret; }


	CoInitialize( NULL );


	IWICImagingFactory    *n_IWICImagingFactory    = NULL;
	IWICBitmapDecoder     *n_IWICBitmapDecoder     = NULL;
	IWICFormatConverter   *n_IWICFormatConverter   = NULL;
	IWICBitmapFrameDecode *n_IWICBitmapFrameDecode = NULL;

	HRESULT hr = CoCreateInstance
	(
		        &CLSID_WICImagingFactory,
		          NULL,
		         CLSCTX_INPROC_SERVER,
		        &IID_IWICImagingFactory,
		(void*) &n_IWICImagingFactory
	);

	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "WICImagingFactory" );

		goto cleanup;
	}


#ifdef UNICODE
	const wchar_t *str = name;
#else  // #ifdef UNICODE
	wchar_t *str = n_posix_ansi2unicode( name );
#endif // #ifdef UNICODE

	hr = n_IWICImagingFactory->lpVtbl->CreateDecoderFromFilename
	(
		         n_IWICImagingFactory,
		         str,
		         NULL,
		         GENERIC_READ,
		         WICDecodeMetadataCacheOnDemand,
		(void*) &n_IWICBitmapDecoder
	);

#ifdef UNICODE
	//
#else  // #ifdef UNICODE
	n_memory_free( str );
#endif // #ifdef UNICODE

	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "CreateDecoderFromFilename" );

		goto cleanup;
	}


	hr = n_IWICImagingFactory->lpVtbl->CreateFormatConverter
	(
		         n_IWICImagingFactory,
		(void*) &n_IWICFormatConverter
	);

	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "CreateFormatConverter" );
		goto cleanup;
	}


	hr = n_IWICBitmapDecoder->lpVtbl->GetFrame
	(
		         n_IWICBitmapDecoder,
		         0,
		(void*) &n_IWICBitmapFrameDecode
	);

	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "GetFrame" );
		goto cleanup;
	}


	UINT sx = 0;
	UINT sy = 0;
	n_IWICBitmapFrameDecode->lpVtbl->GetSize
	(
		 n_IWICBitmapFrameDecode,
		&sx, &sy
	);

	WICPixelFormatGUID n_WICPixelFormatGUID;
        n_IWICBitmapFrameDecode->lpVtbl->GetPixelFormat
	(
		 n_IWICBitmapFrameDecode,
		&n_WICPixelFormatGUID
	);


	n_IWICFormatConverter->lpVtbl->Initialize
	(
		         n_IWICFormatConverter,
		(void*)  n_IWICBitmapFrameDecode,
		        &GUID_WICPixelFormat32bppPBGRA,
		         WICBitmapDitherTypeNone,
		         NULL,
		         0.0,
		         WICBitmapPaletteTypeCustom
	);


	UINT bytesPerPixel = 4;
	UINT stride        = sx * bytesPerPixel;
	UINT size          = stride * sy;

	n_bmp_free( bmp );
	n_bmp_new( bmp, sx,sy );

	n_IWICFormatConverter->lpVtbl->CopyPixels
	(
		        n_IWICFormatConverter,
		        NULL,
		        stride,
		        size,
		(void*) N_BMP_PTR( bmp )
	);

	n_bmp_flush_mirror( bmp, N_BMP_MIRROR_UPSIDE_DOWN );

	ret = n_posix_false;


	cleanup:

	if ( n_IWICBitmapFrameDecode != NULL ) { n_IWICBitmapFrameDecode->lpVtbl->Release( n_IWICBitmapFrameDecode ); }
	if ( n_IWICFormatConverter   != NULL ) { n_IWICFormatConverter  ->lpVtbl->Release( n_IWICFormatConverter   ); }
	if ( n_IWICBitmapDecoder     != NULL ) { n_IWICBitmapDecoder    ->lpVtbl->Release( n_IWICBitmapDecoder     ); }
	if ( n_IWICImagingFactory    != NULL ) { n_IWICImagingFactory   ->lpVtbl->Release( n_IWICImagingFactory    ); }


	CoUninitialize();


	return ret;
}




#endif // _H_NONNON_WIN32_WIC

