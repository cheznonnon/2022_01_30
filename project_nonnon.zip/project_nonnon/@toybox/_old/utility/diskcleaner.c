

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <time.h>




int
main( int argc, char *argv[] )
{

	char str[ 1024 ];

	FILE *fp;

	unsigned long i;
	unsigned long size = ( 1024 * 1024 );

	char *ptr;
	int  ret;

	unsigned long tm, p_tm;


	ptr = malloc( size );
	memset( ptr, 0, size );


	p_tm = time( NULL );

	sprintf( str, "%lu", p_tm );

	fp = fopen( str, "ab" );
	if ( fp == NULL ) { return 0; }


	i = 0;
	while( 1 )
	{

		ret = fwrite( ptr, size, 1, fp );

		if ( ret!=1 ) { break; }
//printf( "%s : %d \n", str, ret );


		i++;
		if ( i >= 100 )
		{

			tm = time( NULL );

			printf( "%lu Sec/%lu MB \n", tm - p_tm, i );

			p_tm = tm;


			i = 0;

		}
	}


	fclose( fp );


	free( ptr );


	return 0;
}

