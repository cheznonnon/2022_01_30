

void
n_win_windowplacement_test( HWND hwnd )
{


	WINDOWPLACEMENT wp = {

		sizeof( WINDOWPLACEMENT ),
		0, SW_NORMAL,
		{ 0,0 },
		{ 100,100 },
		{ 200,200,400,400 }

	};


	SetWindowPlacement( hwnd, &wp );


	return;
}

void
n_win_rtl_onoff( HWND hwnd )
{

	n_win_exstyle_new
	(
		hwnd,
		WS_EX_LAYOUTRTL |
		WS_EX_LEFTSCROLLBAR | WS_EX_RIGHT |
		WS_EX_RTLREADING
	);


	return;
}

bool
n_win_startingpath( n_posix_char *str )
{    

	// [x] : Win95 : not available


	const int STARTF_TITLESHORTCUT = 0x800;


	STARTUPINFO si = { sizeof( si ) };


	GetStartupInfo( &si );


	if ( si.dwFlags & STARTF_TITLESHORTCUT )
	{

		n_string_copy( si.lpTitle, str );


		return true;
	}


	return false;
}

int
n_win_gui_combo_isselected( HWND hgui, const char *str )
{

	const int cur = n_win_message_send( hgui, CB_GETCURSEL,      0, 0 );
	const int len = n_win_message_send( hgui, CB_GETLBTEXTLEN, cur, 0 );


	char *s;


	s = calloc( len + 1, sizeof( char ) );

	n_win_message_send( hgui, CB_GETLBTEXT, cur, (LPARAM) s );


	return strcmp( s, str );
}

void
n_win_doublebuffer( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	// [!] : for flicker-free resizing
	//
	//	XP or later only
	//	heavy
	//	titlebar buttons cannot be hilighted


	static bool onoff = false;


	switch( msg ) {


	case WM_CREATE :

		n_win_exstyle_add( hwnd, WS_EX_COMPOSITED );

	break;


	case WM_DROPFILES :

		// [Patch] : status bar erases edit controls' border

		if ( onoff == false )
		{
			n_win_refresh( hwnd, true );
		}

	break;


	case WM_NCMOUSEMOVE :

		if (
			( HTMINBUTTON == wparam )
			||
			( HTMAXBUTTON == wparam )
			||
			( HTCLOSE     == wparam )
		)
		{
			if ( onoff == false )
			{
				onoff = true;
				n_win_exstyle_del( hwnd, WS_EX_COMPOSITED );
			}

		} else {

			if ( onoff )
			{
				onoff = false;
				n_win_exstyle_add( hwnd, WS_EX_COMPOSITED );
			}

		}

	break;

	case WM_MOUSEMOVE :

		if ( onoff )
		{
			onoff = false;
			n_win_exstyle_add( hwnd, WS_EX_COMPOSITED );
		}

	break;


	} // switch


	return;
}

void
n_win_allredraw( HWND hwnd )
{

	// [Mechanism]
	//
	//	useful in WS_OVERLAPPEDWINDOW
	//
	//	WS_CLIPCHILDREN is needed
	//
	//	n_win_set()  : use N_WIN_SET_NOREDRAW
	//	n_win_move() : use false for redraw


	int rdw;


	rdw  = RDW_INVALIDATE;
	rdw |= RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN;
	rdw |= RDW_UPDATENOW;

	RedrawWindow( hwnd, NULL,NULL, rdw );


	return;
}

