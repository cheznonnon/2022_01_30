// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_paint_canvas_zoom_bitmap( void )
{
//n_bmp_new( bmp, sx,sy ); return;


	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = 0;
	gdi.sy                  = 0;
	gdi.scale               = (double) n_win_scale( hwnd_main ) * 2;//N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = n_bmp_white_invisible;

	gdi.text                = NULL;
	gdi.text_font           = n_project_stdfont();
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	gdi.text_color_main     = n_bmp_black;
	gdi.text_color_contour  = n_bmp_white;
	gdi.text_fxsize2        = gdi.scale;


	gdi.text_size = n_paint_desktop_sx / 50;
//n_win_hwndprintf_literal( hwnd_main, " %d ", gdi.text_size );

	gdi.text = n_posix_literal( "Zoom In" );
	n_gdi_bmp( &gdi, &n_paint_bmp_zoom_i );

	gdi.sx = gdi.sy = 0;
	gdi.text = n_posix_literal( "Zoom Out" );
	n_gdi_bmp( &gdi, &n_paint_bmp_zoom_o );


	return;
}

n_bool
n_paint_canvas_layername_bitmap( void )
{

	if ( n_paint_layer_onoff == n_false ) { return n_false; }


	if ( NULL != N_BMP_PTR( &n_paint_bmp_name ) ) { return n_false; }


	n_gdi gdi; n_gdi_zero( &gdi );


	n_type_int y = n_paint_layer_txtbox.select_cch_y;
	n_posix_char str[ 100 ];

	if ( n_string_is_empty( n_paint_layer_data[ y ].name ) )
	{
		n_posix_sprintf_literal( str, "%02lld", y );
	} else {
		n_posix_sprintf_literal( str, "%02lld : %s", y, n_paint_layer_data[ y ].name );
	}

	gdi.sx                  = 0;
	gdi.sy                  = 0;
	gdi.scale               = (double) n_win_scale( hwnd_main ) * 2;//N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = n_bmp_white_invisible;

	gdi.text                = str;
	gdi.text_font           = n_project_stdfont();
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	//gdi.text_color_main     = n_bmp_black;
	//gdi.text_color_contour  = n_bmp_white;
	gdi.text_fxsize2        = gdi.scale * 1;

	n_type_gfx msy; n_paint_margin_get( NULL, &msy );
	gdi.text_size = (double) msy / 3 * 2;
//n_win_hwndprintf_literal( hwnd_main, " %d ", gdi.text_size );


	gdi.text_color_contour = n_bmp_white;

	if ( n_paint_bmp_name_count & 1 )
	{
		gdi.text_color_main = n_bmp_rgb( 255,0,150 );
	} else {
		gdi.text_color_main = n_bmp_rgb( 0,150,255 );
	}


	n_gdi_bmp( &gdi, &n_paint_bmp_name );


	return n_true;
}

inline u32
n_paint_canvas_grabber_pixel( n_bmp *grab, n_type_gfx x, n_type_gfx y, u32 color )
{

	u32 color_grab; n_paint_grabber_pixel_get( grab, x, y, 0, &color_grab, NULL, 0.0 );


	if ( n_paint_tool_per_pixel_alpha_onoff )
	{

		int a = n_bmp_a( color_grab );

		if ( a != N_BMP_ALPHA_CHANNEL_VISIBLE )
		{
			double b = n_bmp_blend_alpha2ratio( a );
			color_grab = n_bmp_blend_pixel( color_grab, color, b );
		}

	}


	if ( n_paint_tool_blend )
	{
		color_grab = n_bmp_blend_pixel( color_grab, color, n_paint_tool_blend_ratio );
	}


	return color_grab;
}

inline u32
n_paint_canvas_grabber_alpha_pixel( n_type_gfx tx, n_type_gfx ty, u32 color )
{

	int a = n_bmp_a( color );

	if ( a == N_BMP_ALPHA_CHANNEL_VISIBLE   ) { return color; }
	if ( a == N_BMP_ALPHA_CHANNEL_INVISIBLE ) { return N_PAINT_CANVAS_COLOR; }


	u32 color_canvas = N_PAINT_CANVAS_COLOR;

	if (
//(0)&&
		( grabber )
		&&
		( n_paint_tool_per_pixel_alpha_onoff )
		&&
		( n_paint_layer_onoff == n_false )
	)
	{

		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

		n_type_gfx gx = tx - x;
		n_type_gfx gy = ty - y;

		if ( n_bmp_ptr_is_accessible( n_paint_bmp_grab, gx,gy ) )
		{

			color_canvas = n_bmp_composite_pixel( n_paint_bmp_grab, n_paint_bmp_data, gx,gy, tx,ty, n_false,n_false, n_paint_grabber_finalize_onoff, n_paint_tool_blend_ratio );

			color_canvas = n_bmp_blend_pixel
			(
				color_canvas, N_PAINT_CANVAS_COLOR,
				n_bmp_blend_alpha2ratio( n_bmp_a( color_canvas ) )
			);

		} else {

			color_canvas = n_bmp_blend_pixel
			(
				color, color_canvas,
				n_bmp_blend_alpha2ratio( a )
			);

		}

	} else {

		color_canvas = n_bmp_blend_pixel
		(
			color, color_canvas,
			n_bmp_blend_alpha2ratio( a )
		);

	}


	return color_canvas;
}

inline u32
n_paint_highcontrast_pixel( u32 color )
{

	//static u32 cache_color = 0;
	//static u32 cache_ret   = 0;

	//if ( cache_color == color ) { return cache_ret; }

	//cache_color = color;


	if ( n_false )
	{

		int a = n_bmp_a( color );
		int r = n_bmp_r( color );
		int g = n_bmp_g( color );
		int b = n_bmp_b( color );

		r = g = b = ( r + g + b ) / 3;

		color = n_bmp_blend_pixel( ~n_bmp_alpha_invisible_pixel( color ), n_bmp_argb( a,r,g,b ), 0.8 );

	} else {

		color = n_bmp_argb2ahsl( color );

		int a = n_bmp_a( color );
		int h = n_bmp_h( color ) -  32;
		int s = n_bmp_s( color ) /   8;
		int l = n_bmp_l( color );

		color = n_bmp_ahsl2argb( n_bmp_ahsl( a,h,s,l ) );

	}


	//cache_ret = color;

	return color;

}

inline u32
n_paint_pixelgrid_pixel( u32 color )
{

	color = n_bmp_argb2ahsl( color );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color ) + 128;
	int s = n_bmp_s( color ) + 128;
	int l = n_bmp_l( color ) + 128;

	color = n_bmp_ahsl2argb( n_bmp_argb( a,h,s,l ) );


	return color;
}

void
n_paint_refresh_calc( void )
{

	n_type_gfx canvas_ox = 0;
	n_type_gfx canvas_oy = 0;

	n_paint_margin_get( &canvas_ox, &canvas_oy );

	n_type_gfx sx = N_BMP_SX( n_paint_bmp_data );
	n_type_gfx sy = N_BMP_SY( n_paint_bmp_data );

	n_paint_zoom_bitmap2canvas( NULL, NULL, &sx, &sy );

	sx += ( canvas_ox * 2 );
	sy += ( canvas_oy * 2 );


	n_type_gfx scrmax_x = nwin_main.rcsx - nwin_main.csx;
	n_type_gfx scrmax_y = nwin_main.rcsy - nwin_main.csy;

	if ( nwin_main.scrollx <        0 ) { nwin_main.scrollx =        0; }
	if ( nwin_main.scrolly <        0 ) { nwin_main.scrolly =        0; }
	if ( nwin_main.scrollx > scrmax_x ) { nwin_main.scrollx = scrmax_x; }
	if ( nwin_main.scrolly > scrmax_y ) { nwin_main.scrolly = scrmax_y; }


	return;
}

typedef struct {

	n_type_gfx bitmap_fx, bitmap_fy, bitmap_z, bitmap_tx, bitmap_ty;
	n_type_gfx canvas_fx, canvas_fy, canvas_z, canvas_sx, canvas_sy;

	RECT frame_outer;
	RECT frame_inner;

	n_bool z_out;

	n_type_gfx grid_center_fx, grid_center_fy;
	n_type_gfx grid_center_tx, grid_center_ty;
	n_type_gfx grid_unit;

	n_posix_bool is_scroll;

	n_type_int id;
	n_type_int thread_count;

} n_paint_refresh_thread_struct;

void
n_paint_refresh_thread_main( n_paint_refresh_thread_struct *p )
{
//return;

	double grid_blend = 0.25;


	n_type_gfx bitmap_start_x = p->bitmap_fx;
	n_type_gfx canvas_start_x = p->canvas_fx;


	while( 1 )
	{//break;

//if ( p->bitmap_fx <             0 ) { n_posix_debug_literal( "L" ); break; }
//if ( p->bitmap_fy <             0 ) { n_posix_debug_literal( "U" ); break; }
//if ( p->bitmap_fx >= p->bitmap_tx ) { n_posix_debug_literal( "R" ); break; }
//if ( p->bitmap_fy >= p->bitmap_ty ) { n_posix_debug_literal( "D" ); break; }


		u32 color = 0;

		if ( n_paint_layer_onoff )
		{

			if ( p->is_scroll )
			{
				n_bmp_ptr_get( &n_paint_bmp_scrl, p->bitmap_fx, p->bitmap_fy, &color );
				if ( color == 0 )
				{
					color = n_bmp_layer_ptr_get( n_paint_layer_data, p->bitmap_fx, p->bitmap_fy, n_false, 0, n_true );
				}
			} else {
				color = n_bmp_layer_ptr_get( n_paint_layer_data, p->bitmap_fx, p->bitmap_fy, n_false, 0, n_true );
			}

			n_bmp_ptr_set( &n_paint_bmp_scrl, p->bitmap_fx, p->bitmap_fy, color );

		} else {

			if ( NULL != N_BMP_PTR( n_paint_bmp_data ) )
			{
				if ( n_bmp_is_multithread )
				{
					n_bmp_ptr_get     ( n_paint_bmp_data, p->bitmap_fx, p->bitmap_fy, &color );
				} else {
					n_bmp_ptr_get_fast( n_paint_bmp_data, p->bitmap_fx, p->bitmap_fy, &color );
				}
			}

		}


		// [!] : n_paint_canvas_grabber_alpha_pixel() sets canvas bg color

		n_bool contour_onoff = n_false;
		u32    contour_color = color;


		if ( grabber )
		{

			POINT pt = { p->bitmap_fx, p->bitmap_fy };

			n_bool outer_onoff = PtInRect( &p->frame_outer, pt );
			n_bool inner_onoff = PtInRect( &p->frame_inner, pt );

			if ( outer_onoff )
			{
				if ( n_paint_layer_onoff )
				{
					//
				} else {
					color = contour_color = n_paint_canvas_grabber_pixel( n_paint_bmp_grab, p->bitmap_fx, p->bitmap_fy, color );
				}
			}

			color = n_paint_canvas_grabber_alpha_pixel( p->bitmap_fx, p->bitmap_fy, color );

			if (
				( outer_onoff )
				&&
				( inner_onoff == n_false )
			)
			{

				u32 grid_color = n_bmp_alpha_visible_pixel( ~color );

				if (
					( ( p->z_out == n_false )&&( n_bmp_moire_detect( p->bitmap_fx, p->bitmap_fy, 1 ) ) )
					||
					( ( p->z_out != n_false )&&( n_bmp_moire_detect( p->canvas_fx, p->canvas_fy, 1 ) ) )
				)
				{
					color = n_bmp_blend_pixel( n_bmp_white, grid_color, 0.5 );
				} else {
					color = n_bmp_blend_pixel( n_bmp_black, grid_color, 0.5 );
				}

				if (
					( n_paint_layer_onoff )
					&&
					( n_paint_layer_txtbox.select_cch_y != n_paint_grabber_selected_index )
				)
				{
					color = n_bmp_blend_pixel( color, grid_color, 0.5 );
				}

			}

		} else {

			color = n_paint_canvas_grabber_alpha_pixel( p->bitmap_fx,p->bitmap_fy, color );

		}


		// [!] : checker background

		int alpha = n_bmp_a( color );

		if ( N_BMP_ALPHA_CHANNEL_VISIBLE != alpha )
		{
			u32 c = n_bmp_checker_pixel( p->bitmap_fx, p->bitmap_fy, N_BMP_SX( n_paint_bmp_data ), N_BMP_SY( n_paint_bmp_data ), N_PAINT_CANVAS_COLOR );
			color = n_bmp_blend_pixel( color, c, n_bmp_blend_alpha2ratio( alpha ) );
		}


		if ( graycanvas ) { color = n_paint_highcontrast_pixel( color ); }


		if ( pixelgrid )
		{

			u32 c = n_paint_pixelgrid_pixel( contour_color );

			contour_onoff = n_true;
			contour_color = n_bmp_blend_pixel( contour_color, c, grid_blend );

		}


		if ( grid )
		{
//if ( p->grid_unit <= 0 ) { break; }

			POINT vert_pt = { p->canvas_fx, 0 };
			RECT  vert_rc = { p->grid_center_fx, 0, p->grid_center_tx + 1, 1 };

			POINT horz_pt = { p->canvas_fy, 0 };
			RECT  horz_rc = { p->grid_center_fy, 0, p->grid_center_ty + 1, 1 };

			if (
				( PtInRect( &vert_rc, vert_pt ) )
				||
				( PtInRect( &horz_rc, horz_pt ) )
			)
			{

				u32 c = n_bmp_rgb( 255,0,128 );

				contour_onoff = n_true;
				contour_color = n_bmp_blend_pixel( contour_color, c, grid_blend );

			} else {

				n_type_gfx gfx = abs( p->canvas_fx - p->grid_center_fx ) % p->grid_unit;
				n_type_gfx gtx = abs( p->canvas_fx - p->grid_center_tx ) % p->grid_unit;

				n_bool gfx_is_frame = ( ( gfx == 0 )||( gfx == ( p->grid_unit - p->canvas_z ) ) );
				n_bool gtx_is_frame = ( ( gtx == 0 )||( gtx == ( p->grid_unit - p->canvas_z ) ) );

				n_type_gfx gfy = abs( p->canvas_fy - p->grid_center_fy ) % p->grid_unit;
				n_type_gfx gty = abs( p->canvas_fy - p->grid_center_ty ) % p->grid_unit;

				n_bool gfy_is_frame = ( ( gfy == 0 )||( gfy == ( p->grid_unit - p->canvas_z ) ) );
				n_bool gty_is_frame = ( ( gty == 0 )||( gty == ( p->grid_unit - p->canvas_z ) ) );

				if (
					( ( p->canvas_fx <= p->grid_center_fx )&&( gfx_is_frame ) )
					||
					( ( p->canvas_fx >= p->grid_center_tx )&&( gtx_is_frame ) )
					||
					( ( p->canvas_fy <= p->grid_center_fy )&&( gfy_is_frame ) )
					||
					( ( p->canvas_fy >= p->grid_center_ty )&&( gty_is_frame ) )
				)
				{

					u32 c = n_bmp_rgb( 0,128,255 );

					contour_onoff = n_true;
					contour_color = n_bmp_blend_pixel( contour_color, c, grid_blend );

				}

			}

		}


		// [!] : n_bmp_box() : 2x slower than below loop

		//n_bmp_box( &n_paint_bmp_dbuf, p->canvas_fx, p->canvas_fy, p->canvas_z, p->canvas_z, color_new );

		n_type_gfx zoom_fx = n_posix_minmax( 0, p->canvas_sx - 1, p->canvas_fx );
		n_type_gfx zoom_fy = n_posix_minmax( 0, p->canvas_sy - 1, p->canvas_fy );
		n_type_gfx zoom_tx = n_posix_minmax( 0, p->canvas_sx - 0, p->canvas_fx + p->canvas_z );
		n_type_gfx zoom_ty = n_posix_minmax( 0, p->canvas_sy - 0, p->canvas_fy + p->canvas_z );

		n_type_gfx zoom_start_x = zoom_fx;
		n_type_gfx zoom_start_y = zoom_fy;

//if ( p->id == 0 ) { color = n_bmp_rgb(   0,200,255 ); }
//if ( p->id == 1 ) { color = n_bmp_rgb(   0,255,200 ); }
//if ( p->id == 2 ) { color = n_bmp_rgb( 255,200,  0 ); }
//if ( p->id == 3 ) { color = n_bmp_rgb( 255,  0,200 ); }

		if ( NULL != N_BMP_PTR( &n_paint_bmp_dbuf ) )
		{

			while( 1 )
			{

				u32 clr = color;

				if (
					( contour_onoff )
					&&
					(
						( zoom_fx == zoom_start_x )||( zoom_fx == ( zoom_tx - 1 ) )
						||
						( zoom_fy == zoom_start_y )||( zoom_fy == ( zoom_ty - 1 ) )
					)
				)
				{
					//if ( n_bmp_moire_detect( zoom_fx, zoom_fy, 1 ) )
					//{
						clr = contour_color;
					//} else {
						//clr = ~color;
					//}
				}


				n_bmp_ptr_set( &n_paint_bmp_dbuf, zoom_fx, zoom_fy, clr );


				zoom_fx++;
				if ( zoom_fx >= zoom_tx )
				{

					zoom_fx = zoom_start_x;

					zoom_fy++;
					if ( zoom_fy >= zoom_ty ) { break; }
				}
			}

		}


		p->bitmap_fx += p->bitmap_z;
		p->canvas_fx += p->canvas_z;

		if ( ( p->bitmap_fx >= p->bitmap_tx )||( p->canvas_fx >= p->canvas_sx ) )
		{

			p->bitmap_fx = bitmap_start_x;
			p->canvas_fx = canvas_start_x;


			p->bitmap_fy += p->bitmap_z * p->thread_count;
			p->canvas_fy += p->canvas_z * p->thread_count;

			if ( ( p->bitmap_fy >= p->bitmap_ty )||( p->canvas_fy >= p->canvas_sy ) ) { break; }
		}
	}


	return;
}

DWORD WINAPI
n_paint_refresh_thread( LPVOID lpParameter )
{

	n_paint_refresh_thread_main( (void*) lpParameter );

	return 0;
}

void
n_paint_refresh( HDC hdc, n_type_gfx fx, n_type_gfx fy, n_type_gfx tx, n_type_gfx ty, int mode, int id )
{

	// [Needed] : reduce number of accesses at startup

	if ( n_paint_refresh_lock ) { return; }

	if ( n_false == IsWindow( hwnd_main ) ) { return; }
	if ( NULL == N_BMP_PTR( n_paint_bmp_data ) ) { return; }


	if ( n_paint_pen_straight_line )
	{
		fx = 0;
		fy = 0;
		tx = N_BMP_SX( n_paint_bmp_data );
		ty = N_BMP_SY( n_paint_bmp_data );
	}


	if ( n_paint_is_shiftzoom )
	{
		fx = 0;
		fy = 0;
		tx = N_BMP_SX( n_paint_bmp_data );
		ty = N_BMP_SY( n_paint_bmp_data );
	}



	// Debug Center

	const n_bool debug_counter    = n_false;
	const n_bool debug_benchmark  = n_false;
	const n_bool background_onoff = n_true;
	const n_bool n_gdi_draw_onoff = n_true;

	u32 tick = 0;


	if ( debug_counter )
	{

		static int w = 0;
		static int c = 0;

		n_win_hwndprintf_literal( hwnd_main, "ID %d : W %d : C %d", id, w, c );

		if ( mode & N_PAINT_REFRESH_WINDOW ) { w++; }
		if ( mode & N_PAINT_REFRESH_CLIENT ) { c++; }

	}


	// Init

	const n_type_gfx bitmap_sx = N_BMP_SX( n_paint_bmp_data );
	const n_type_gfx bitmap_sy = N_BMP_SY( n_paint_bmp_data );

	const n_type_gfx z     = n_paint_zoom_get( zoom );
	const n_bool     z_out = n_paint_is_zoom_out( zoom );


	// Window and Canvas

	n_type_gfx canvas_ox = 0;
	n_type_gfx canvas_oy = 0;

	n_paint_margin_get( &canvas_ox, &canvas_oy );

	static n_type_gfx canvas_sx = 0;
	static n_type_gfx canvas_sy = 0;

	if ( mode & N_PAINT_REFRESH_WINDOW )
	{

		int nwinset = N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING | N_WIN_SET_SCROLLBAR;

		n_type_gfx sx = bitmap_sx;
		n_type_gfx sy = bitmap_sy;

		n_paint_zoom_bitmap2canvas( NULL, NULL, &sx, &sy );

		sx += ( canvas_ox * 2 );
		sy += ( canvas_oy * 2 );

		n_win_set( hwnd_main, &nwin_main, sx,sy, nwinset | N_WIN_SET_CALCONLY );

		canvas_sx = nwin_main.csx;// - ( canvas_ox * 2 );
		canvas_sy = nwin_main.csy;// - ( canvas_oy * 2 );


		static n_type_gfx psx = 0;
		static n_type_gfx psy = 0;

		if (
			( ( psx != sx )||( psy != sy ) )
			//||
			//( ( nwin_main.rcsx != canvas_sx )||( nwin_main.rcsy != canvas_sy ) )
		)
		{
//n_win_debug_count( hwnd_main );
//n_posix_debug_literal( "%d %d : %d %d", nwin_main.rcsx, canvas_sx, nwin_main.rcsy, canvas_sy );

			psx = sx;
			psy = sy;


//n_bmp_new_fast( &n_paint_bmp_dbuf, canvas_sx, canvas_sy );

			n_type_gfx dbuf_sx = canvas_sx;
			n_type_gfx dbuf_sy = canvas_sy;

			n_gdi_dibsection_init( &n_paint_dibsection, &n_paint_bmp_dbuf, hwnd_main, NULL, dbuf_sx,dbuf_sy );
			n_bmp_flush( &n_paint_bmp_dbuf, N_PAINT_CANVAS_COLOR );

#ifdef _H_NONNON_WIN32_GAME_DIRECT2D
			if ( n_direct2d_is_on() )
			{
//n_win_hwndprintf_literal( hwnd_main, "Direct2D1", 0 );
				n_direct2d_make( hwnd_main, N_BMP_PTR( &n_paint_bmp_dbuf ), canvas_sx,canvas_sy );
			}
#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D

		}

	}


	//if ( mode & N_PAINT_REFRESH_SCROLL )
	{

		n_type_gfx scr_fx = nwin_main.scrollx;
		n_type_gfx scr_fy = nwin_main.scrolly;
		n_type_gfx scr_tx = nwin_main.scrollx + canvas_sx;
		n_type_gfx scr_ty = nwin_main.scrolly + canvas_sy;

		n_paint_zoom_canvas2bitmap( &scr_fx, &scr_fy, &scr_tx, &scr_ty );

		fx = n_posix_max_n_type_gfx( fx, scr_fx );
		fy = n_posix_max_n_type_gfx( fy, scr_fy );
		tx = n_posix_min_n_type_gfx( tx, scr_tx );
		ty = n_posix_min_n_type_gfx( ty, scr_ty );

		// [!] : for modulo

		tx = n_posix_min_n_type_gfx( tx + 1, bitmap_sx );
		ty = n_posix_min_n_type_gfx( ty + 1, bitmap_sy );

	}


	if ( z_out )
	{

		fx -= fx % z;
		fy -= fy % z;
		tx += z - ( tx % z );
		ty += z - ( ty % z );

	}


	// Grabber : always needed for n_paint_grabber_finish()

	n_type_gfx frame_size = 1;
	if ( z_out ) { frame_size = z; }

	fx = n_posix_max_n_type_gfx( fx - frame_size,         0 );
	fy = n_posix_max_n_type_gfx( fy - frame_size,         0 );
	tx = n_posix_min_n_type_gfx( tx + frame_size, bitmap_sx );
	ty = n_posix_min_n_type_gfx( ty + frame_size, bitmap_sy );


	// Clip

	if ( fx >= tx ) { return; }
	if ( fy >= ty ) { return; }

//n_win_hwndprintf_literal( hwnd_main, "%d %d %d %d", fx, fy, tx, ty );return;

	fx = n_posix_min_n_type_gfx( n_posix_max_n_type_gfx( 0, fx ), bitmap_sx );
	fy = n_posix_min_n_type_gfx( n_posix_max_n_type_gfx( 0, fy ), bitmap_sy );
	tx = n_posix_min_n_type_gfx( n_posix_max_n_type_gfx( 0, tx ), bitmap_sx );
	ty = n_posix_min_n_type_gfx( n_posix_max_n_type_gfx( 0, ty ), bitmap_sy );

//n_win_hwndprintf_literal( hwnd_main, "%d %d %d %d", fx, fy, tx, ty );return;


	{ // Redraw


	if ( debug_benchmark ) { tick = n_posix_tickcount(); }


	// Zoom


	n_type_int bitmap_z = 1;
	n_type_int canvas_z = z;

	if ( z_out )
	{
		bitmap_z = z;
		canvas_z = 1;
	}


	n_type_gfx bitmap_fx = fx;
	n_type_gfx bitmap_fy = fy;
	n_type_gfx bitmap_tx = tx;
	n_type_gfx bitmap_ty = ty;
	n_type_gfx canvas_fx = fx;
	n_type_gfx canvas_fy = fy;

	n_paint_zoom_bitmap2canvas( &canvas_fx, &canvas_fy, NULL, NULL );

	canvas_fx -= nwin_main.scrollx;
	canvas_fy -= nwin_main.scrolly;

	canvas_fx += canvas_ox;
	canvas_fy += canvas_oy;


	// [!] : this position is important

	n_type_gfx redraw_x  = canvas_fx;
	n_type_gfx redraw_y  = canvas_fy;
	n_type_gfx redraw_sx = ( tx - fx ) * canvas_z;
	n_type_gfx redraw_sy = ( ty - fy ) * canvas_z;

	redraw_x  -= canvas_ox;
	redraw_y  -= canvas_oy;
	redraw_sx += canvas_ox * 2;
	redraw_sy += canvas_oy * 2;

	if ( redraw_x < 0 ) { redraw_sx += redraw_x; redraw_x = 0; }
	if ( redraw_y < 0 ) { redraw_sy += redraw_y; redraw_y = 0; }

//n_bmp_box( &n_paint_bmp_dbuf, redraw_x, redraw_y, redraw_sx, redraw_sy, n_bmp_black );
//redraw_x = redraw_y = 0;
//redraw_sx = canvas_sx;
//redraw_sy = canvas_sy;


	// Grid

	n_type_gfx grid_center_fx = 0;
	n_type_gfx grid_center_fy = 0;
	n_type_gfx grid_center_tx = 0;
	n_type_gfx grid_center_ty = 0;
	n_type_gfx grid_unit      = 0;

	if ( grid )
	{

		// Center Line

		grid_center_fx = grid_center_tx = ( bitmap_sx / 2 );
		grid_center_fy = grid_center_ty = ( bitmap_sy / 2 );

		grid_center_fx -= ( 0 == ( bitmap_sx % 2 ) );
		grid_center_fy -= ( 0 == ( bitmap_sy % 2 ) );

		n_paint_zoom_bitmap2canvas( &grid_center_fx, &grid_center_fy, &grid_center_tx, &grid_center_ty );

		grid_center_fx -= nwin_main.scrollx;
		grid_center_fy -= nwin_main.scrolly;
		grid_center_tx -= nwin_main.scrollx;
		grid_center_ty -= nwin_main.scrolly;

		grid_center_fx += canvas_ox;
		grid_center_fy += canvas_oy;
		grid_center_tx += canvas_ox;
		grid_center_ty += canvas_oy;


		// Guide Line

		const n_type_gfx unit     = n_posix_min_n_type_gfx( bitmap_sx, bitmap_sy );
		const n_type_gfx unit_min = 16;

		grid_unit = n_posix_max_n_type_gfx( unit_min, unit / unit_min );
		n_paint_zoom_bitmap2canvas( &grid_unit, NULL, NULL, NULL );
		grid_unit = n_posix_max_n_type_gfx( 1, grid_unit );

//n_win_hwndprintf_literal( hwnd_main, "%d", grid_unit );
	}


	// Grabber Frame : Bitmap-based : Thick Frame

	RECT frame_outer = { 0,0,0,0 };
	RECT frame_inner = { 0,0,0,0 };

	if ( grabber )
	{

		n_type_gfx frame_fx, frame_fy, frame_tx, frame_ty;
		n_paint_grabber_system_get( &frame_fx, &frame_fy, &frame_tx, &frame_ty, NULL,NULL );

		frame_tx += frame_fx;
		frame_ty += frame_fy;

		frame_fx = n_posix_max_n_type_gfx(         0 - frame_size, frame_fx - frame_size );
		frame_fy = n_posix_max_n_type_gfx(         0 - frame_size, frame_fy - frame_size );
		frame_tx = n_posix_min_n_type_gfx( bitmap_sx + frame_size, frame_tx + frame_size );
		frame_ty = n_posix_min_n_type_gfx( bitmap_sy + frame_size, frame_ty + frame_size );

		frame_outer = frame_inner = n_win_rect_set_simple( NULL, frame_fx, frame_fy, frame_tx, frame_ty );

		n_win_rect_resize( &frame_inner, -frame_size, -frame_size );

	}


	// Combined Scale Copy


	n_paint_hmutex = n_win_mutex_init( n_paint_hmutex, N_PAINT_MUTEX_REFRESH );
	if ( n_paint_hmutex == NULL ) { return; }


	// [x] : Win9x : can run but not working

	if ( n_false == ( mode & N_PAINT_REFRESH_CLIENT ) )
	{

		// [!] : do nothing

	} else
	if (
//(0)&&
		( n_paint_thread_onoff )
		&&
		( n_thread_onoff() )
		//&&
		//( ( canvas_fy * canvas_sy ) >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{
//n_win_hwndprintf_literal( hwnd_main, " Multi-thread On " );


		n_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_true;


		u32 cores = n_thread_core_count;


		n_thread                      *h = n_memory_new( cores * sizeof( n_thread                      ) );
		n_paint_refresh_thread_struct *p = n_memory_new( cores * sizeof( n_paint_refresh_thread_struct ) );


		u32 i = 0;
		while( 1 )
		{

			n_paint_refresh_thread_struct tmp =
			{
				bitmap_fx, bitmap_fy + ( bitmap_z * i ), bitmap_z, bitmap_tx, bitmap_ty,
				canvas_fx, canvas_fy + ( canvas_z * i ), canvas_z, canvas_sx, canvas_sy,
				frame_outer, frame_inner,
				z_out,
				grid_center_fx, grid_center_fy, grid_center_tx, grid_center_ty, grid_unit,
				( mode & N_PAINT_REFRESH_SCROLL ),
				i,
				cores
			};

			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_refresh_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_refresh_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {
//n_win_hwndprintf_literal( hwnd_main, " Multi-thread Off " );

		n_paint_refresh_thread_struct p =
		{
			bitmap_fx,bitmap_fy,bitmap_z,bitmap_tx,bitmap_ty,
			canvas_fx,canvas_fy,canvas_z,canvas_sx,canvas_sy,
			frame_outer,frame_inner,
			z_out,
			grid_center_fx,grid_center_fy,
			grid_center_tx,grid_center_ty,
			grid_unit,
			( mode & N_PAINT_REFRESH_SCROLL ),
			0,1
		};

		n_paint_refresh_thread_main( &p );

	}


	if ( background_onoff )
	{

		n_bmp_box( &n_paint_bmp_dbuf, 0,                    0, canvas_sx, canvas_oy, N_PAINT_CANVAS_COLOR );
		n_bmp_box( &n_paint_bmp_dbuf, 0,canvas_sy - canvas_oy, canvas_sx, canvas_oy, N_PAINT_CANVAS_COLOR );
		n_bmp_box( &n_paint_bmp_dbuf, 0,                    0, canvas_ox, canvas_sy, N_PAINT_CANVAS_COLOR );
		n_bmp_box( &n_paint_bmp_dbuf, canvas_sx - canvas_ox,0, canvas_ox, canvas_sy, N_PAINT_CANVAS_COLOR );

		if ( grid )
		{

			COLORREF fg = n_bmp_white;
			COLORREF bg = n_bmp_black + 1;

			n_type_gfx m  = canvas_ox;
			n_type_gfx x  = 0;
			n_type_gfx y  = 0;
			n_type_gfx sx = bitmap_sx;
			n_type_gfx sy = bitmap_sy;

			n_paint_zoom_bitmap2canvas( &x, &y, &sx, &sy );

			x = -nwin_main.scrollx + m;
			y = -nwin_main.scrolly + m;


			// [!] : WinVista or later : this logic is heavy because lack of 2D acceleration

			//RECT r; GetClientRect( hwnd_main, &r );
			//n_draw_gdi_frame2canvas( hdc, x,y,sx,sy, r, fg, bg );


			n_bmp_line_dot( &n_paint_bmp_dbuf, x, y - 1, x + sx, y - 1, fg, 1 );
			n_bmp_line_dot( &n_paint_bmp_dbuf, x, y - 1, x + sx, y - 1, bg, 2 );

			n_bmp_line_dot( &n_paint_bmp_dbuf, x, y + sy, x + sx, y + sy, fg, 1 );
			n_bmp_line_dot( &n_paint_bmp_dbuf, x, y + sy, x + sx, y + sy, bg, 2 );

			n_bmp_line_dot( &n_paint_bmp_dbuf, x - 1, y, x - 1, y + sy, fg, 1 );
			n_bmp_line_dot( &n_paint_bmp_dbuf, x - 1, y, x - 1, y + sy, bg, 2 );

			n_bmp_line_dot( &n_paint_bmp_dbuf, x + sx, y, x + sx, y + sy, fg, 1 );
			n_bmp_line_dot( &n_paint_bmp_dbuf, x + sx, y, x + sx, y + sy, bg, 2 );

		}

	}


	// Window #2 : for smooth zooming

	if ( mode & N_PAINT_REFRESH_WINDOW )
	{

		int nwinset = N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING | N_WIN_SET_SCROLLBAR;

		n_type_gfx sx = bitmap_sx;
		n_type_gfx sy = bitmap_sy;

		n_paint_zoom_bitmap2canvas( NULL, NULL, &sx, &sy );

		sx += ( canvas_ox * 2 );
		sy += ( canvas_oy * 2 );

		n_win_set( hwnd_main, &nwin_main, sx,sy, nwinset );
		n_paint_prev_scrollx = n_paint_prev_scrolly = 0;

		n_win_scrollbar_window( &n_paint_hscr, &n_paint_vscr, &nwin_main, N_PAINT_CANVAS_COLOR );

	}


	// Scrollbars

	//if ( mode & N_PAINT_REFRESH_SCROLL )
	{

		n_win_scrollbar_client( &n_paint_hscr, &n_paint_vscr, &nwin_main, N_PAINT_CANVAS_COLOR );

		// [Needed] : Classic Style

		n_bmp_free( &n_paint_hscr.bmp_th );
		n_bmp_free( &n_paint_vscr.bmp_th );

		n_win_scrollbar_draw_always( &n_paint_hscr, n_true );
		n_win_scrollbar_draw_always( &n_paint_vscr, n_true );

	}


	// Pen : straight line

	if ( ( z_out == n_false )&&( n_paint_pen_straight_line ) )
	{

		n_type_gfx c_fx = n_paint_pen_start_x;
		n_type_gfx c_fy = n_paint_pen_start_y;
		n_type_gfx c_tx = 0;
		n_type_gfx c_ty = 0;

		n_paint_zoom_bitmap2canvas( &c_fx, &c_fy, NULL, NULL );
		n_win_cursor_position_relative( hwnd_main, &c_tx, &c_ty );

		n_type_gfx canvas_ox = 0;
		n_type_gfx canvas_oy = 0;
		n_paint_margin_get( &canvas_ox, &canvas_oy );

		c_fx += canvas_ox;
		c_fy += canvas_oy;

		c_fx -= nwin_main.scrollx;
		c_fy -= nwin_main.scrolly;

		n_type_gfx circle = n_posix_max( 8, z * pensize );

		n_draw_line( &n_paint_bmp_dbuf, c_fx,c_fy, c_tx,c_ty, n_paint_pen_color, circle, z * pensize );

	}


	// Hamburger Button

	{

		u32 color_base = n_bmp_alpha_visible_pixel( N_PAINT_CANVAS_COLOR );

		n_type_gfx x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

		if (
			(
				(
					( tooltype == N_PAINT_TOOL_TYPE_PEN )
					&&
					( n_paint_pen_start == n_false )
				)
				||
				( tooltype == N_PAINT_TOOL_TYPE_FILL )
				||
				(
					( tooltype == N_PAINT_TOOL_TYPE_GRAB )
					&&
					(
						( N_PAINT_GRABBER_IS_NEUTRAL() )
						||
						( N_PAINT_GRABBER_IS_DRAG_OK() )
					)
				)
			)
			&&
			( n_win_is_hovered_offset( hwnd_main, x,y,sx,sy ) )
		)
		{
			u32 fg = n_bmp_blend_pixel( n_bmp_white, color_base, 0.75 );

			if ( n_win_fluent_ui_onoff )
			{
				n_type_gfx round = n_win_fluent_ui_round_param( hwnd_main );
				n_bmp_roundrect_pixel( &n_paint_bmp_dbuf, x,y,sx,sy, fg, round );
			} else {
				n_bmp_box( &n_paint_bmp_dbuf, x,y,sx,sy, fg );
			}
		}

		u32 bg = n_bmp_blend_pixel( n_bmp_black, color_base, 0.75 );

		n_type_gfx scale = ceil( n_win_scale( hwnd_main ) );

		n_type_gfx line_sx  = sx / 3 * 2;
		n_type_gfx line_sy  = 2 * scale;
		n_type_gfx line_gap = 3 * scale;
		n_type_gfx line_x   = ( sx -     line_sx                            ) / 2;
		n_type_gfx line_y   = ( sy - ( ( line_sy * 3 ) + ( line_gap * 2 ) ) ) / 2;

		line_y += line_sy;
		line_y += line_y % 2;

		n_bmp_box( &n_paint_bmp_dbuf, x+line_x,line_y,line_sx,line_sy, bg );
		line_y += line_sy + line_gap;

		n_bmp_box( &n_paint_bmp_dbuf, x+line_x,line_y,line_sx,line_sy, bg );
		line_y += line_sy + line_gap;

		n_bmp_box( &n_paint_bmp_dbuf, x+line_x,line_y,line_sx,line_sy, bg );
		line_y += line_sy + line_gap;

	}


	// Shift Zoom

//n_win_hwndprintf_literal( hwnd_main, " %d %d %d %d ", fx,fy,tx,ty );
//n_win_hwndprintf_literal( hwnd_main, " %d %d %d %d ", redraw_x,redraw_y,redraw_sx,redraw_sy );

	if ( n_paint_is_shiftzoom )
	{
//u32 tick = n_posix_tickcount();

//n_bmp_flush( &n_paint_bmp_dbuf, n_bmp_rgb( 0,200,255 ) );


		n_bmp_flush_mixer( &n_paint_bmp_dbuf, n_bmp_black, 0.5 );


		n_type_gfx tsx = N_BMP_SX( &n_paint_bmp_dbuf );
		n_type_gfx tsy = N_BMP_SY( &n_paint_bmp_dbuf ) / 2;

		{
			n_type_gfx fsx = N_BMP_SX( &n_paint_bmp_zoom_i );
			n_type_gfx fsy = N_BMP_SY( &n_paint_bmp_zoom_i );

			n_type_gfx x = ( tsx - fsx ) / 2;
			n_type_gfx y = ( tsy - fsy ) / 2;

			n_bmp_transcopy( &n_paint_bmp_zoom_i, &n_paint_bmp_dbuf, 0,0,fsx,fsy, x,y );
		}

		n_bmp_line( &n_paint_bmp_dbuf, 0,tsy+0,tsx,tsy+0, n_bmp_white );
		n_bmp_line( &n_paint_bmp_dbuf, 0,tsy+1,tsx,tsy+1, n_bmp_black );

		{
			n_type_gfx fsx = N_BMP_SX( &n_paint_bmp_zoom_o );
			n_type_gfx fsy = N_BMP_SY( &n_paint_bmp_zoom_o );

			n_type_gfx x = ( tsx - fsx ) / 2;
			n_type_gfx y = ( tsy - fsy ) / 2;

			n_bmp_transcopy( &n_paint_bmp_zoom_o, &n_paint_bmp_dbuf, 0,0,fsx,fsy, x,y+tsy );
		}

//n_bmp_save_literal( &n_paint_bmp_dbuf, "dbuf.bmp" );


//n_win_hwndprintf_literal( hwnd_main, " %d ", n_posix_tickcount() - tick );

//static int i = 0; n_win_hwndprintf_literal( hwnd_main, " %d ", i ); i++;
	}


	// Layer Name

	if ( n_paint_layer_onoff )
	{

		n_bool name_redraw = n_paint_canvas_layername_bitmap();

		n_type_gfx canvas_ox, canvas_oy; n_paint_margin_get( &canvas_ox, &canvas_oy );

		n_type_gfx sx = N_BMP_SX( &n_paint_bmp_name );
		n_type_gfx sy = N_BMP_SY( &n_paint_bmp_name );
//n_win_hwndprintf_literal( hwnd_main, " %d %d ", canvas_sx - ( canvas_ox * 2 ) , sx );

		if ( ( canvas_sx - ( canvas_ox * 2 ) ) >= sx )
		{
			n_type_gfx x = ( canvas_sx - sx ) / 2;
			n_type_gfx y = ( canvas_oy - sy ) / 2;

			n_bmp_transcopy( &n_paint_bmp_name, &n_paint_bmp_dbuf, 0,0,sx,sy, x,y );

			// [!] : pen input uses redraw_*

//n_win_hwndprintf_literal( hwnd_main, " %d %d %d %d ", redraw_x, redraw_y, redraw_sx, redraw_sy );
			if ( name_redraw )
			{
				redraw_x  = 0;
				redraw_y  = 0;
				redraw_sx = canvas_sx;//N_BMP_SX( &n_paint_bmp_dbuf );
				redraw_sy = n_posix_max( redraw_sy, canvas_oy );//N_BMP_SY( &n_paint_bmp_dbuf );
			}
//n_bmp_save_literal( &n_paint_bmp_dbuf, "ret.bmp" );
		}

	}


	// Draw
//n_gdi_bitmap_draw( hwnd_main, &n_paint_bmp_dbuf, 0, 0, canvas_sx, canvas_sy, 0, 0 );


	n_type_gfx offset_x = 0;

	if ( n_paint_vscr.show_onoff )
	{
		if ( n_win_is_lefthanded() )
		{
			offset_x = n_win_scrollbar_stdsize( &n_paint_vscr );
		}
	}


#ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	if ( n_direct2d_is_on() )
	{
//n_win_hwndprintf_literal( hwnd_main, "n_direct2d_is_on()" );

		n_direct2d_copy( hwnd_main, N_BMP_PTR( &n_paint_bmp_dbuf ),canvas_sx,canvas_sy, 0,0 );
		n_direct2d_draw( hwnd_main, 0,0, canvas_sx,canvas_sy );

	} else

#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	if ( n_gdi_draw_onoff )
	{
//n_win_hwndprintf_literal( hwnd_main, "n_gdi_draw_onoff" );

		n_gdi_bitmap_draw_main
		(
			hwnd_main, hdc, &n_paint_bmp_dbuf,
			           redraw_x, redraw_y, redraw_sx, redraw_sy,
			offset_x + redraw_x, redraw_y
		);

	}


	if ( debug_benchmark ) { n_win_hwndprintf_literal( hwnd_main, "%d", (int) n_posix_tickcount() - tick ); }


	} // Redraw


	n_paint_hmutex = n_win_mutex_exit( n_paint_hmutex );


	return;
}

