// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_PAINT_LAYER_INI_FILENAME n_posix_literal( "nonnon_paint.ini" )
#define N_PAINT_LAYER_INI_SECTION  n_posix_literal( "[Nonnon Paint Layer]" )
#define N_PAINT_LAYER_INI_INDEX    n_posix_literal( "index  " )
#define N_PAINT_LAYER_INI_NUMBER   n_posix_literal( "number " )
#define N_PAINT_LAYER_INI_NAME     n_posix_literal( "name   " )
#define N_PAINT_LAYER_INI_VISIBLE  n_posix_literal( "visible" )
#define N_PAINT_LAYER_INI_PERCENT  n_posix_literal( "percent" )
#define N_PAINT_LAYER_INI_BLUR     n_posix_literal( "blur   " )
#define N_PAINT_LAYER_TITLE        n_posix_literal( "Layer"   )




static n_win_scroller   n_paint_layer_scr_blend;
static n_win_scroller   n_paint_layer_scr_blur;
static n_win_simplemenu n_paint_layer_simplemenu;
static n_type_int       n_paint_layer_first_index = 0;




void
n_bmp_layer_free( n_paint_layer *p )
{

	n_type_int i = 0;
	while( 1 )
	{

		n_bmp_free( &p[ i ].bmp_data );
		n_bmp_free( &p[ i ].bmp_grab );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	return;
}

#define n_bmp_layer_alias( f, t ) n_memory_copy( f, t, sizeof( n_paint_layer ) * n_paint_layer_count )

void
n_bmp_layer_copy( n_paint_layer *f, n_paint_layer *t )
{

	n_memory_copy( f, t, sizeof( n_paint_layer ) * n_paint_layer_count );

	n_type_int i = 0;
	while( 1 )
	{

		n_bmp_carboncopy( &f[ i ].bmp_data, &t[ i ].bmp_data );
		n_bmp_carboncopy( &f[ i ].bmp_grab, &t[ i ].bmp_grab );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	return;
}

inline u32
n_paint_layer_blur_pixel( n_bmp *bmp, n_type_gfx x, n_type_gfx y, int blur )
{

	u32 ret;


	if ( blur == 0 )
	{
		n_bmp_ptr_get( bmp, x, y, &ret );
	} else
	if ( blur == 1 )
	{
		ret = n_bmp_antialias_pixel( bmp, x, y, 1.0 );
	} else {
		ret = n_bmp_blur_pixel( bmp, x, y, blur, 1, 1.0 );
	}


	return ret;
}

inline u32
n_paint_layer_blur_pixel_fast( n_bmp *bmp, n_type_gfx x, n_type_gfx y, int blur )
{

	u32 ret;


	if ( blur == 0 )
	{
		n_bmp_ptr_get_fast( bmp, x, y, &ret );
	} else
	if ( blur == 1 )
	{
		ret = n_bmp_antialias_pixel( bmp, x, y, 1.0 );
	} else {
		ret = n_bmp_blur_pixel( bmp, x, y, blur, 1, 1.0 );
	}


	return ret;
}

// internal
void
n_paint_layer_grabber_pixel_get( n_bmp *grab, n_type_gfx tx, n_type_gfx ty, u32 picked, u32 *before, u32 *after, double blend, n_type_int i )
{

	// [!] : this module is based on n_paint_grabber_pixel_get()


	u32 color_b, color_a;


	// [x] : don't use _fast()

	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{

		color_b = n_bmp_antialias_pixel( n_paint_bmp_data, tx,ty, blend );
		color_a = picked;

	} else {

		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


		n_type_gfx gx = tx - x;
		n_type_gfx gy = ty - y;

		if ( n_bmp_ptr_is_accessible( grab, gx,gy ) )
		{
			color_b = n_paint_layer_blur_pixel_fast( &n_paint_layer_data[ i ].bmp_grab, gx, gy, n_paint_layer_data[ i ].blur );
		} else {
			color_b = n_paint_layer_blur_pixel( &n_paint_layer_data[ i ].bmp_data, tx, ty, n_paint_layer_data[ i ].blur );
		}


		// [!] : Eraser

		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE == n_bmp_a( picked ) )
		{
			n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &color_a );
		} else {
			color_a = picked;
		}

	}


	if ( before != NULL ) { (*before) = color_b; }
	if ( after  != NULL ) { (*after ) = color_a; }


	return;
}

inline u32
n_paint_layer_canvas_grabber_pixel( n_bmp *grab, n_type_gfx tx, n_type_gfx ty, u32 color, n_type_int i )
{

	// [!] : this module is based on n_paint_canvas_grabber_pixel()

 
	u32 color_grab; n_paint_layer_grabber_pixel_get( grab, tx, ty, 0, &color_grab, NULL, 0.0, i );


	if ( n_paint_tool_per_pixel_alpha_onoff )
	{

		n_type_gfx x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );

		n_bmp *data = &n_paint_layer_data[ i ].bmp_data;

		n_type_gfx gx = tx - x;
		n_type_gfx gy = ty - y;

		if (
			( n_bmp_ptr_is_accessible( grab, gx,gy ) )
			&&
			( n_bmp_ptr_is_accessible( data, tx,ty ) )
		)
		{
			color_grab = n_bmp_composite_pixel_fast( grab, data, gx,gy, tx,ty, n_false,n_false, n_true, 0.0, NULL );
		}
	}


	if ( n_paint_tool_blend )
	{
		color_grab = n_bmp_blend_pixel( color_grab, color, n_paint_tool_blend_ratio );
	}


	return color_grab;
}

u32
n_bmp_layer_ptr_get( n_paint_layer *p, n_type_gfx tx, n_type_gfx ty, n_bool use_color_bg, u32 color_bg, n_bool is_ui )
{

	u32 ret = n_bmp_white_invisible;
//return n_bmp_rgb( 0,200,255 );

	if ( n_false == n_bmp_ptr_is_accessible( &p[ 0 ].bmp_data, tx, ty ) ) { return ret; }


	u32 color_prev = n_paint_layer_blur_pixel_fast( &p[ 0 ].bmp_data, tx, ty, p[ 0 ].blur );

	if ( ( use_color_bg )&&( N_BMP_ALPHA_CHANNEL_INVISIBLE == n_bmp_a( color_prev ) ) )
	{
		ret = color_prev = color_bg;
//return n_bmp_rgb( 0,200,255 );
	} else {
		ret = color_prev;
		if ( n_false == p[ 0 ].visible ) { color_prev = color_bg; }
//return n_bmp_rgb( 255,0,200 );
	}


	n_type_int count = n_paint_layer_count;

	if (
//(0)&&
		( n_paint_fastmode )
		&&
		( ( is_ui )&&( grabber ) )
		&&
		( n_paint_grabber_wholegrb_onoff )
		&&
		( n_paint_whole_preview_onoff == n_posix_false )
		&&
		( n_paint_tool_blend == 0 )
		&&
		( n_paint_tool_per_pixel_alpha_onoff == n_posix_false )
	)
	{
		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

		if (
			( ( x <= tx )&&( ( x + sx ) > tx ) )
			&&
			( ( y <= ty )&&( ( y + sy ) > ty ) )
			&&
			( n_bmp_ptr_is_accessible( &n_paint_bmp_wgrb, tx - x, ty - y ) )
		)
		{
			u32 color = 0; n_bmp_ptr_get_fast( &n_paint_bmp_wgrb, tx - x, ty - y, &color );
			if ( color != 0 )
			{

				count = color;

			} else {

				u32 repeat = 0;

				n_type_int i = n_paint_layer_count - 1;
				while( 1 )
				{//break;

					u32 clr = n_paint_layer_blur_pixel_fast( &p[ i ].bmp_data, tx, ty, p[ i ].blur );
					clr = n_paint_layer_canvas_grabber_pixel( &n_paint_layer_data[ i ].bmp_grab, tx, ty, clr, i );

					if ( clr == n_bmp_white_invisible ) { repeat++; } else { break; }

					i--;
					if ( i < 0 ) { break; }
				}

				repeat = (u32) n_paint_layer_count - repeat;
				n_bmp_ptr_set_fast( &n_paint_bmp_wgrb, tx - x, ty - y, repeat );

			}
		}

	}


	n_type_int i = 0;
	while( 1 )
	{//break;

		if ( p[ i ].visible )
		{

			u32 color;

			if ( i == 0 )
			{
				color = color_prev;
			} else {
				color = n_paint_layer_blur_pixel_fast( &p[ i ].bmp_data, tx, ty, p[ i ].blur );
			}

			if ( ( is_ui )&&( grabber ) )
			{
				color = n_paint_layer_canvas_grabber_pixel( &n_paint_layer_data[ i ].bmp_grab, tx, ty, color, i );
//color = n_bmp_rgb( 0,200,255 );
			}

			ret = n_bmp_composite_pixel_postprocess( color_prev, color, n_bmp_a( color ), n_true, n_true, n_true, 1.0 - p[ i ].blend, NULL );

//if ( n_win_is_input( VK_LBUTTON ) ) { ret = n_bmp_rgb( 0,200,255 ); }

			color_prev = ret;

		} else
		if ( n_paint_whole_preview_onoff )
		{

			u32 color = n_paint_layer_blur_pixel_fast( &p[ i ].bmp_data, tx, ty, p[ i ].blur );
//color = n_bmp_rgb( 0,200,255 );

			ret = n_bmp_composite_pixel_postprocess( color_prev, color, n_bmp_a( color ), n_true, n_true, n_true, 1.0 - p[ i ].blend, NULL );

			color_prev = ret;

		} else {

			ret = color_prev;

		}


		i++;
		if ( i >= count ) { break; }
	}


	return ret;
}

void
n_paint_layercopy_grabber( n_bmp *bmp_ret )
{

	n_type_gfx bmpsx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_grab );
	n_type_gfx bmpsy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_grab );

	n_bmp_new_fast( bmp_ret, bmpsx, bmpsy ); n_bmp_flush( bmp_ret, n_bmp_white_invisible );

	n_type_int i = 0;
	while( 1 )
	{

		n_bmp_flush_blendcopy( &n_paint_layer_data[ i ].bmp_grab, bmp_ret, 1.0 - n_paint_layer_data[ i ].blend );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}

//n_bmp_save_literal( bmp_ret, "ret.bmp" );

	return;
}

typedef struct {

	n_paint_layer *layer;
	n_bmp         *bmp_t;
	n_type_gfx     x,y,sx,sy, tx,ty;
	u32            color_bg;
	n_bool         is_ui;
	u32            oy, cores;

} n_bmp_layercopy_thread_struct;

void
n_bmp_layercopy_thread_main( n_bmp_layercopy_thread_struct *p )
{

	n_type_gfx x = 0;
	n_type_gfx y = p->oy; if ( y >= p->sy ) { return; }
	while( 1 )
	{

		u32 color = n_bmp_layer_ptr_get( p->layer, p->x + x, p->y + y, n_true, p->color_bg, p->is_ui );
		n_bmp_ptr_set_fast( p->bmp_t, p->tx + x, p->ty + y, color );

		x++;
		if ( x >= p->sx )
		{

			x = 0;

			y += p->cores;
			if ( y >= p->sy ) { break; }
		}
	}


	return;
}

n_thread_return
n_bmp_layercopy_thread( n_thread_argument p )
{

	n_bmp_layercopy_thread_main( p );

	return 0;
}

// internal
void
n_bmp_layercopy_main( n_paint_layer *layer, n_bmp *bmp, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_type_gfx tx, n_type_gfx ty, u32 color_bg, n_bool is_ui )
{
//return;

	if ( n_bmp_error_clipping( &layer[ 0 ].bmp_data,bmp, &x,&y,&sx,&sy, &tx,&ty ) ) { return; }


	// [x] : Win9x : can run but not working

	// [!] : very heavy : multi-thread is always needed

	if (
//(0)&&
		( n_paint_thread_onoff )
		&&
		( n_thread_onoff() )
		//&&
		//( ( sx * sy ) >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_bmp_layercopy() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_true;


		u32 cores = n_thread_core_count;

		n_thread                      *h = n_memory_new( cores * sizeof( n_thread                      ) );
		n_bmp_layercopy_thread_struct *p = n_memory_new( cores * sizeof( n_bmp_layercopy_thread_struct ) );


		u32 i = 0;
		while( 1 )
		{

			n_bmp_layercopy_thread_struct tmp = { layer, bmp, x,y,sx,sy, tx,ty, color_bg, is_ui, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_bmp_layercopy_thread_struct ) );

			h[ i ] = n_thread_init( n_bmp_layercopy_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_bmp_layercopy_thread_struct p = { layer, bmp, x,y,sx,sy, tx,ty, color_bg, is_ui, 0,1 };

		n_bmp_layercopy_thread_main( &p );

	}


	return;
}

void
n_bmp_layer_fill( n_paint_layer *p, n_type_gfx x, n_type_gfx y, u32 color )
{

	// [x] : this module is something wrong

	// [!] : fail-safe

	u32 color_to;

	n_type_int found = 0;
	n_type_int index = 0;
	while( 1 )
	{
		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_bmp_ptr_get( &p[ index ].bmp_data, x,y, &color_to );
		} else {
			n_bmp_ptr_get( &p[ index ].bmp_grab, x,y, &color_to );
		}
		if ( color == color_to ) { found++; }

		index++;
		if ( index >= n_paint_layer_count ) { break; }
	}
//n_posix_debug_literal( " %d ", found ); return;
	if ( found != 0 ) { return; }


	n_type_gfx bmpsx = N_BMP_SX( &p[ 0 ].bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( &p[ 0 ].bmp_data );

	u8 *map = n_memory_new_closed( bmpsx * bmpsy * sizeof( u8 ) );


	u32 t    = 0;
	int move = 0;
	int stop = 0;
	u32 i    = 0;
	while( 1 )
	{

		int found = 0;
		int index = 0;
		while( 1 )
		{

			if ( p[ index ].visible )
			{
				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					n_bool ret = n_bmp_ptr_get( &p[ index ].bmp_data, x,y, &t );
					if ( ( ret == n_false )&&( t == color_to ) ) { found++; }
				} else {
					n_bool ret = n_bmp_ptr_get( &p[ index ].bmp_grab, x,y, &t );
					if ( ( ret == n_false )&&( t == color_to ) ) { found++; }
				}
			} else {
				found++;
			}

			index++;
			if ( index >= n_paint_layer_count ) { break; }
		}

		if ( found == n_paint_layer_count )
		{

			stop = 0;

			int index = 0;
			while( 1 )
			{

				if ( p[ index ].visible )
				{
					if ( N_PAINT_GRABBER_IS_NEUTRAL() )
					{
						n_bmp_ptr_set( &p[ index ].bmp_data, x,y, color );
					} else {
						n_bmp_ptr_set( &p[ index ].bmp_grab, x,y, color );
					}
				}

				index++;
				if ( index >= n_paint_layer_count ) { break; }
			}

			map[ i ] = move;

			i++;

		} else {

			if ( move == 0 ) { y++; } else
			if ( move == 1 ) { x--; } else
			if ( move == 2 ) { y--; } else
			if ( move == 3 ) { x++; }

			stop++;
			if ( stop >= 4 )
			{

				stop = 0;

				if ( i <= 1 ) { break; }


				i--;

				move = map[ i ];
				if ( move == 0 ) { y++; } else
				if ( move == 1 ) { x--; } else
				if ( move == 2 ) { y--; } else
				if ( move == 3 ) { x++; }

			}

			move++;
			if ( move >= 4 ) { move = 0; }

		}

		if ( move == 0 ) { y--; } else
		if ( move == 1 ) { x++; } else
		if ( move == 2 ) { y++; } else
		if ( move == 3 ) { x--; }

	}


	n_memory_free_closed( map );


	return;
}




void
n_paint_layer_bmp_flush( u32 color )
{

	if ( n_paint_grabber_wholegrb_onoff )
	{

		n_type_int i = 0;
		while( 1 )
		{

			if ( n_paint_layer_data[ i ].visible )
			{
				n_paint_layer_is_mod[ i ] = n_true;

				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					n_bmp_flush( &n_paint_layer_data[ i ].bmp_data, color );
				} else {
					n_bmp_flush( &n_paint_layer_data[ i ].bmp_grab, color );
				}
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( n_paint_layer_onoff )
	{

		n_type_int y = n_paint_layer_txtbox.select_cch_y;

		if ( n_paint_layer_data[ y ].visible )
		{
			n_paint_layer_is_mod[ y ] = n_true;

			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				n_bmp_flush( n_paint_bmp_data, color );
			} else {
				n_bmp_flush( n_paint_bmp_grab, color );
			}
		}

	} else {

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_bmp_flush( n_paint_bmp_data, color );
		} else {
			n_bmp_flush( n_paint_bmp_grab, color );
		}

	}

	return;
}

void
n_paint_layer_bmp_alpha( int mode )
{

	if ( n_paint_grabber_wholegrb_onoff )
	{

		n_type_int i = 0;
		while( 1 )
		{

			if ( n_paint_layer_data[ i ].visible )
			{
				n_paint_layer_is_mod[ i ] = n_true;

				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					if ( mode == N_PAINT_FILTER_ALPHA_CLR )
					{
						n_bmp_alpha_visible( &n_paint_layer_data[ i ].bmp_data );
					} else
					if ( mode == N_PAINT_FILTER_ALPHA_REV )
					{
						n_bmp_alpha_reverse( &n_paint_layer_data[ i ].bmp_data );
					}// else
				} else {
					if ( mode == N_PAINT_FILTER_ALPHA_CLR )
					{
						n_bmp_alpha_visible( &n_paint_layer_data[ i ].bmp_grab );
					} else
					if ( mode == N_PAINT_FILTER_ALPHA_REV )
					{
						n_bmp_alpha_reverse( &n_paint_layer_data[ i ].bmp_grab );
					}// else
				}
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( n_paint_layer_onoff )
	{

		n_type_int y = n_paint_layer_txtbox.select_cch_y;

		if ( n_paint_layer_data[ y ].visible )
		{
			n_paint_layer_is_mod[ y ] = n_true;

			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				if ( mode == N_PAINT_FILTER_ALPHA_CLR )
				{
					n_bmp_alpha_visible( n_paint_bmp_data );
				} else
				if ( mode == N_PAINT_FILTER_ALPHA_REV )
				{
					n_bmp_alpha_reverse( n_paint_bmp_data );
				}// else
			} else {
				if ( mode == N_PAINT_FILTER_ALPHA_CLR )
				{
					n_bmp_alpha_visible( n_paint_bmp_grab );
				} else
				if ( mode == N_PAINT_FILTER_ALPHA_REV )
				{
					n_bmp_alpha_reverse( n_paint_bmp_grab );
				}// else
			}
		}

	} else {

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			if ( mode == N_PAINT_FILTER_ALPHA_CLR )
			{
				n_bmp_alpha_visible( n_paint_bmp_data );
			} else
			if ( mode == N_PAINT_FILTER_ALPHA_REV )
			{
				n_bmp_alpha_reverse( n_paint_bmp_data );
			}// else
		} else {
			if ( mode == N_PAINT_FILTER_ALPHA_CLR )
			{
				n_bmp_alpha_visible( n_paint_bmp_grab );
			} else
			if ( mode == N_PAINT_FILTER_ALPHA_REV )
			{
				n_bmp_alpha_reverse( n_paint_bmp_grab );
			}// else
		}

	}


	return;
}

void
n_paint_layer_bmp_flush_replacer( u32 f, u32 t )
{

	if ( n_paint_grabber_wholegrb_onoff )
	{

		n_type_int i = 0;
		while( 1 )
		{

			if ( n_paint_layer_data[ i ].visible )
			{
				n_paint_layer_is_mod[ i ] = n_true;

				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					n_bmp_flush_replacer( &n_paint_layer_data[ i ].bmp_data, f, t );
				} else {
					n_bmp_flush_replacer( &n_paint_layer_data[ i ].bmp_grab, f, t );
				}
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( n_paint_layer_onoff )
	{

		n_type_int y = n_paint_layer_txtbox.select_cch_y;

		if ( n_paint_layer_data[ y ].visible )
		{
			n_paint_layer_is_mod[ y ] = n_true;

			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				n_bmp_flush_replacer( n_paint_bmp_data, f, t );
			} else {
				n_bmp_flush_replacer( n_paint_bmp_grab, f, t );
			}
		}

	} else {

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_bmp_flush_replacer( n_paint_bmp_data, f, t );
		} else {
			n_bmp_flush_replacer( n_paint_bmp_grab, f, t );
		}

	}


	return;
}

n_bool
n_paint_layer_bmp_fill( n_bmp *bmp )
{

	n_paint_cache_zero( &n_paint_bmp_scrl );
	n_paint_cache_zero( &n_paint_bmp_wgrb );


	u32 color = n_bmp_argb( cp.a, cp.r, cp.g, cp.b );

	n_type_gfx tx,ty; n_paint_canvaspos( &tx,&ty );

	if ( n_paint_grabber_wholegrb_onoff )
	{

		n_project_dialog_info( hwnd_main, n_posix_literal( "Sorry, not implemented yet." ) );
/*
		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{

			n_bmp_layer_fill( n_paint_layer_data, tx,ty, color );

		} else {

			n_type_gfx x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );

			n_bmp_layer_fill( n_paint_layer_data, tx - x,ty - y, color );

		}

		n_paint_refresh_client();
*/
		return n_true;

	} else
	if ( n_paint_layer_onoff )
	{

		n_type_int index = n_paint_layer_txtbox.select_cch_y;

		if ( n_paint_layer_data[ index ].visible )
		{
			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				n_bmp_fill( n_paint_bmp_data, tx,ty, color );

				n_paint_refresh_client();

				return n_true;
			} else {
				n_type_gfx x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );
				n_bmp_fill( &n_paint_layer_data[ n_paint_grabber_selected_index ].bmp_grab, tx - x, ty - y, color );

				n_paint_refresh_client();

				return n_true;
			}
		}

	} else {

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{

			n_bmp_fill( n_paint_bmp_data, tx,ty, color );
			n_paint_refresh_client();

			return n_true;
		}

		n_type_gfx x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );

		n_bmp_carboncopy( n_paint_bmp_grab, bmp );
		n_bmp_fill( bmp, tx - x, ty - y, color );

	}


	return n_false;
}




// internal
LRESULT CALLBACK
n_paint_layer_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( wparam == VK_RETURN )
	{
		ShowWindow( hwnd, SW_HIDE );
		SetFocus( n_paint_layer_txtbox.hwnd );

		return n_true;
	}


	return n_false;
}

void
n_paint_layer_on_keydown_init( void )
{

	HWND hgui = n_paint_layer_rename.hwnd;

#ifdef _WIN64

	SetWindowSubclass( hgui, n_win_subclass_txtbox_on_keydown, 0, (DWORD_PTR) n_paint_layer_on_keydown );

#else  // #ifdef _WIN64

	n_win_property_init_literal
	(
		hgui,
		"n_win_subclass_txtbox_on_keydown()",
		(int) n_win_gui_subclass_set( hgui, n_win_subclass_txtbox_on_keydown )
	);

	n_win_property_init_literal( hgui, "WM_KEYDOWN", (int) n_paint_layer_on_keydown );

#endif // #ifdef _WIN64


	return;
}

void
n_paint_layer_on_keydown_exit( void )
{

	HWND hgui = n_paint_layer_rename.hwnd;

#ifdef _WIN64

	RemoveWindowSubclass( hgui, n_win_subclass_txtbox_on_keydown, 0 );

#else  // #ifdef _WIN64

	n_win_property_exit_literal
	(
		hgui,
		"n_win_subclass_txtbox_on_keydown()"
	);

	n_win_property_exit_literal( hgui, "WM_KEYDOWN" );

#endif // #ifdef _WIN64


	return;
}




#define n_paint_layer_selection_move_up(   y ) n_paint_layer_selection_move( y, n_true  )
#define n_paint_layer_selection_move_down( y ) n_paint_layer_selection_move( y, n_false )

// internal
void
n_paint_layer_selection_move( n_type_int y, n_bool is_up )
{

	if ( n_paint_layer_rename_onoff ) { return; }


	if ( is_up )
	{
		if ( y <= 0 ) { return; }

		n_paint_layer_txtbox.select_cch_y--;
	} else {
		if ( y >= ( n_paint_layer_count - 1 ) ) { return; }

		n_paint_layer_txtbox.select_cch_y++;
	}


	n_paint_layer_rename_target = n_paint_layer_txtbox.select_cch_y;


	n_paint_bmp_data = &n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].bmp_data;
	n_paint_bmp_grab = &n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].bmp_grab;


	int percent = n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].percent;
	n_win_hwndprintf_literal( n_paint_layer_scr_blend.value, "%3d%%", percent );
	n_win_refresh( n_paint_layer_scr_blend.value, n_true );

	int blur = n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].blur;
	n_win_hwndprintf_literal( n_paint_layer_scr_blur.value, "%3d", blur );
	n_win_refresh( n_paint_layer_scr_blur.value, n_true );

	n_win_scroller_scroll_parameter( &n_paint_layer_scr_blend, 1, 10, 100, percent, n_false );
	n_win_scroller_scroll_parameter( &n_paint_layer_scr_blur , 1,  5,  25, blur   , n_false );

	if ( n_paint_layer_txtbox.select_cch_y == 0 )
	{
		nwscr_enable( &n_paint_layer_scr_blend, n_false );
	} else {
		nwscr_enable( &n_paint_layer_scr_blend, n_true  );
	}


	n_win_txtbox_autofocus( &n_paint_layer_txtbox );
	n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );

	n_bmp_free( &n_paint_bmp_name );
	n_paint_bmp_name_count++;

	n_paint_refresh_client();


	return;
}

#define n_paint_layer_swap_up(   y ) n_paint_layer_swap( y, n_true  )
#define n_paint_layer_swap_down( y ) n_paint_layer_swap( y, n_false )

// internal
void
n_paint_layer_swap( n_type_int y, n_bool is_up )
{

	if ( n_paint_layer_rename_onoff ) { return; }


	if ( is_up )
	{
		if ( y <= 0 ) { n_paint_layer_rename_target = 0; return; }

		n_paint_layer data_tmp      = n_paint_layer_data[ y - 1 ];
		n_paint_layer_data[ y - 1 ] = n_paint_layer_data[ y     ];
		n_paint_layer_data[ y     ] =               data_tmp;

		n_posix_char *txtbox_tmp_line          = n_paint_layer_txtbox.txt.line[ y - 1 ];
		n_paint_layer_txtbox.txt.line[ y - 1 ] = n_paint_layer_txtbox.txt.line[ y     ];
		n_paint_layer_txtbox.txt.line[ y     ] = txtbox_tmp_line;

		n_paint_layer_txtbox.select_cch_y--;
	} else {
		if ( y >= ( n_paint_layer_count - 1 ) ) { n_paint_layer_rename_target = ( n_paint_layer_count - 1 ); return; }

		n_paint_layer data_tmp      = n_paint_layer_data[ y + 1 ];
		n_paint_layer_data[ y + 1 ] = n_paint_layer_data[ y     ];
		n_paint_layer_data[ y     ] =               data_tmp;

		n_posix_char *txtbox_tmp_line          = n_paint_layer_txtbox.txt.line[ y + 1 ];
		n_paint_layer_txtbox.txt.line[ y + 1 ] = n_paint_layer_txtbox.txt.line[ y     ];
		n_paint_layer_txtbox.txt.line[ y     ] = txtbox_tmp_line;

		n_paint_layer_txtbox.select_cch_y++;
	}


	n_paint_layer_rename_target = n_paint_layer_txtbox.select_cch_y;


	n_paint_bmp_data = &n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].bmp_data;
	n_paint_bmp_grab = &n_paint_layer_data[ n_paint_layer_txtbox.select_cch_y ].bmp_grab;


	n_win_txtbox_autofocus( &n_paint_layer_txtbox );
	n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );


	n_type_int i = 0;
	while( 1 )
	{

		n_paint_layer_is_mod[ i ] = n_true;

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	n_bmp_free( &n_paint_bmp_name );
	n_paint_refresh_client();


	return;
}

void
n_paint_layer_config_default( void )
{

	n_type_int i = 0;
	while( 1 )
	{
		n_paint_layer_data[ i ].visible = n_true;
		n_paint_layer_data[ i ].percent =    100;
		n_paint_layer_data[ i ].blend   =    1.0;
		n_paint_layer_data[ i ].blur    =      0;

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	return;
}

void
n_paint_layer_init( void )
{

	n_paint_layer_onoff = n_false;

	{
		n_type_int i = 0;
		while( 1 )
		{
			n_bmp_zero( &n_paint_layer_data[ i ].bmp_data );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}
	}

	n_paint_layer_config_default();

	n_bmp_zero( &n_paint_layer_as_one );

	n_ini_zero( &n_paint_layer_ini );


	n_win_simplemenu_zero( &n_paint_layer_simplemenu );

	n_win_txtbox_zero( &n_paint_layer_txtbox );
	n_win_txtbox_zero( &n_paint_layer_rename );

	n_win_scroller_zero( &n_paint_layer_scr_blend );
	n_win_scroller_zero( &n_paint_layer_scr_blur  );


	return;
}

void
n_paint_layer_reset( void )
{

	n_paint_layer_onoff = n_false;

	{
		n_type_int i = 1;
		while( 1 )
		{
			n_bmp_free_fast( &n_paint_layer_data[ i ].bmp_data );

			n_paint_layer_zero( &n_paint_layer_data[ i ] );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

		n_paint_bmp_data = &n_paint_layer_data[ 0 ].bmp_data;
		n_paint_bmp_grab = &n_paint_layer_data[ 0 ].bmp_grab;
	}

	n_bmp_free( &n_paint_layer_as_one );

	n_ini_free( &n_paint_layer_ini );


	return;
}

void
n_paint_layer_exit( void )
{

	n_paint_layer_onoff = n_false;

	{
		n_type_int i = 0;
		while( 1 )
		{
			n_bmp_free( &n_paint_layer_data[ i ].bmp_data );
			n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );

			n_paint_layer_zero( &n_paint_layer_data[ i ] );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}
	}

	n_bmp_free( &n_paint_layer_as_one );

	n_ini_free( &n_paint_layer_ini );


	n_win_simplemenu_exit( &n_paint_layer_simplemenu );

	n_paint_layer_on_keydown_exit();

	n_win_txtbox_exit( &n_paint_layer_txtbox );
	n_win_txtbox_exit( &n_paint_layer_rename );

	n_win_scroller_exit( &n_paint_layer_scr_blend );
	n_win_scroller_exit( &n_paint_layer_scr_blur  );

	n_win_check_exit( &n_paint_layer_chk_wholegrb );
	n_win_check_exit( &n_paint_layer_chk_wholepvw );

	//n_win_statusbar_od_exit( &n_paint_layer_statusbar );


	return;
}

#define n_paint_layer_ini_read(  i ) n_paint_layer_ini_main( i, n_true  )
#define n_paint_layer_ini_write( i ) n_paint_layer_ini_main( i, n_false )

// internal
void
n_paint_layer_ini_main( n_ini *ini, n_bool is_read )
{

	if ( is_read )
	{
		n_type_int index;

		n_posix_char *name = n_string_path_carboncopy( n_paint_bmpname );
		if ( n_paint_format_is_lyr( name ) ) { n_string_path_ext_del( name ); }

		if ( n_false == n_string_is_same( name, n_paint_layer_name_main ) )
			{
			n_posix_char str[ 100 ];
			n_ini_value_str( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_INDEX, N_STRING_EMPTY, str, 100 );
			index = n_posix_atoi( str );
		} else {
			index = n_paint_layer_txtbox.select_cch_y;
		}
//n_posix_debug_literal( " %s : %d ", str, n_paint_layer_first_index );

		n_paint_layer_first_index = n_posix_minmax_n_type_int( 0, n_paint_layer_count - 1, index );
//n_posix_debug_literal( " %d ", n_paint_layer_first_index );

		n_string_path_free( name );
	}


	n_type_int i = n_paint_layer_count - 1;
	while( 1 )
	{
		n_posix_char section[ 100 ];
		n_posix_sprintf_literal( section, "[%lld]", i );

		n_ini_section_add( ini, section );

		if ( is_read )
		{
			n_posix_char str[ N_PAINT_LAYER_CCH ];
			n_ini_value_str( ini, section, N_PAINT_LAYER_INI_NAME, N_STRING_EMPTY, str, N_PAINT_LAYER_CCH );

			n_bool visible = n_ini_value_int( ini, section, N_PAINT_LAYER_INI_VISIBLE, n_true );
			int    percent = n_ini_value_int( ini, section, N_PAINT_LAYER_INI_PERCENT,    100 );
			int       blur = n_ini_value_int( ini, section, N_PAINT_LAYER_INI_BLUR   ,      0 );

			n_string_copy( str, n_paint_layer_data[ i ].name );

			n_paint_layer_data[ i ].visible = visible;
			n_paint_layer_data[ i ].percent = percent;
			n_paint_layer_data[ i ].blur    = blur;
			n_paint_layer_data[ i ].blend   = (double) percent * 0.01;
		} else {
			n_posix_char str[ N_PAINT_LAYER_CCH ];
			n_string_copy( n_paint_layer_data[ i ].name, str );
//n_posix_debug_literal( " ini_write() : %s", n_paint_layer_data[ i ].name );

			n_bool visible = n_paint_layer_data[ i ].visible;
			int    percent = n_paint_layer_data[ i ].percent;
			int       blur = n_paint_layer_data[ i ].blur;

			n_ini_key_add_str( ini, section, N_PAINT_LAYER_INI_NAME, str );

			n_ini_key_add_int( ini, section, N_PAINT_LAYER_INI_VISIBLE, visible );
			n_ini_key_add_int( ini, section, N_PAINT_LAYER_INI_PERCENT, percent );
			n_ini_key_add_int( ini, section, N_PAINT_LAYER_INI_BLUR   , blur    );
		}

		i--;
		if ( i < 0 ) { break; }
	}


	if ( is_read )
	{
		n_ini_new( ini );
	} else {
		n_ini_section_add( ini, N_PAINT_LAYER_INI_SECTION );
		n_ini_key_add_int( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_INDEX , (int) n_paint_layer_txtbox.select_cch_y );
		n_ini_key_add_int( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_NUMBER, (int) n_paint_layer_count               );
	}


	return;
}

void
n_paint_layer_ui_init( n_posix_char *name, n_ini *ini, n_bool is_init )
{

	if ( ini != &n_paint_layer_ini )
	{
		n_paint_layer_ini_read( ini );
//n_posix_debug_literal( " %d ", n_paint_layer_data[ n_paint_layer_count - 1 ].percent );

		n_ini_free( &n_paint_layer_ini );
		n_memory_copy( ini, &n_paint_layer_ini, sizeof( n_ini ) );
	}

/*
	i = 0;
	while( 1 )
	{

n_posix_debug_literal( " %d ", n_paint_layer_data[ i ].percent );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}
*/

	n_type_int cch = n_posix_strlen( name ) + n_posix_strlen( N_PAINT_EXT_LYR );

	n_string_path_free( n_paint_bmpname );
	n_paint_bmpname = n_string_alloccopy( cch, name );
	n_string_path_ext_mod( N_PAINT_EXT_LYR, n_paint_bmpname );

	n_paint_format = N_PAINT_FORMAT_LYR;


	n_win_txtbox_reset( &n_paint_layer_txtbox );

	n_type_int i = 0;
	while( 1 )
	{

		n_posix_char str[ 100 ];
		if ( n_paint_layer_data[ i ].visible )
		{
			n_posix_sprintf_literal( str, "[B]%s", n_paint_layer_data[ i ].name );
		} else {
			n_posix_sprintf_literal( str, "[ ]%s", n_paint_layer_data[ i ].name );
		}

		n_win_txtbox_line_set( &n_paint_layer_txtbox, i, str );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}

//n_posix_debug_literal( " %d ", n_paint_layer_first_index );
	n_win_txtbox_line_select( &n_paint_layer_txtbox, n_paint_layer_first_index );

	n_type_int y = n_paint_layer_txtbox.select_cch_y;

	n_paint_layer_rename_target = y;


	int percent = n_paint_layer_data[ y ].percent;
	n_win_hwndprintf_literal( n_paint_layer_scr_blend.value, "%3d%%", percent );
	n_win_refresh( n_paint_layer_scr_blend.value, n_true );

	int blur = n_paint_layer_data[ y ].blur;
	n_win_hwndprintf_literal( n_paint_layer_scr_blur.value, "%3d", blur );
	n_win_refresh( n_paint_layer_scr_blur.value, n_true );

	n_win_scroller_scroll_parameter( &n_paint_layer_scr_blend, 1, 10, 100, percent, n_true );
	n_win_scroller_scroll_parameter( &n_paint_layer_scr_blur , 1,  5,  25, blur   , n_true );

	if ( y == 0 )
	{
		nwscr_enable( &n_paint_layer_scr_blend, n_false );
	} else {
		nwscr_enable( &n_paint_layer_scr_blend, n_true  );
	}


	n_win_txtbox_line_select( &n_paint_layer_txtbox, y );
	n_paint_bmp_data = &n_paint_layer_data[ y ].bmp_data;
	n_paint_bmp_grab = &n_paint_layer_data[ y ].bmp_grab;

	n_win_txtbox_autofocus( &n_paint_layer_txtbox );
	n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );


	//n_win_statusbar_od_automove( &n_paint_layer_statusbar );


	n_paint_layer_onoff = n_true;

	extern void n_paint_layer_resize( HWND hwnd, n_bool shade_onoff, n_bool is_init );
	n_paint_layer_resize( hwnd_layr, n_paint_layer_shade_onoff, is_init );


	ShowWindowAsync( hwnd_layr, SW_NORMAL );


	return;
}

n_bool
n_paint_layer_load_sniffer( const n_posix_char *cmdline )
{

	n_posix_char *name_ini = n_string_path_make_new( cmdline, N_PAINT_LAYER_INI_FILENAME );
//n_posix_debug_literal( "%s", name_ini );

	n_bool ret = ( n_false == n_posix_stat_is_exist( name_ini ) );

	n_string_path_free( name_ini );


	return ret;
}

typedef struct {

	n_posix_char *name_base;
	n_bmp        *bmp;
	n_type_int    layer_count;
	n_type_gfx    sx,sy;
	n_type_int    oy, cores;

	u32           is_finished;

} n_paint_load_thread_struct;

void
n_paint_load_thread_main( n_paint_load_thread_struct *p )
{
//return;

	if ( p->oy >= p->layer_count ) { p->is_finished = 1; return; }

	n_bmp *bmp = &p->bmp[ p->oy ];


	n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%lld.png", p->oy );
	n_posix_char *name_img = n_string_path_make_new( p->name_base, str );


	n_bool ret = n_png_png2bmp( name_img, bmp );
	if ( ret )
	{
		n_bmp_new_fast( bmp, p->sx, p->sy );
		n_bmp_flush( bmp, n_bmp_white_invisible );
	} else
	if (
		( p->sx != N_BMP_SX( bmp ) )
		||
		( p->sy != N_BMP_SY( bmp ) )
	)
	{
		n_bmp_resizer( bmp, p->sx, p->sy, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );
	}


	n_string_path_free( name_img );


	p->is_finished = 1;


	return;
}

n_thread_return
n_paint_load_thread( n_thread_argument p )
{

	n_paint_load_thread_main( (void*) p );

	return 0;
}

void
n_paint_load_main( n_posix_char *name_base, n_bmp *bmp, n_type_int layer_count, n_type_gfx sx, n_type_gfx sy )
{

	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_paint_thread_onoff )
		&&
		( n_thread_onoff() )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_paint_load_main() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		n_type_int cores = layer_count;//n_thread_core_count;

		n_thread                   *h = (void*) n_memory_new( cores * sizeof( n_thread                   ) );
		n_paint_load_thread_struct *p = (void*) n_memory_new( cores * sizeof( n_paint_load_thread_struct ) );

		n_type_int i = 1;
		while( 1 )
		{

			n_paint_load_thread_struct tmp = { name_base, bmp, layer_count, sx,sy, i,cores, n_false };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_load_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_load_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		n_paint_progressbar progressbar;
		n_paint_progressbar_init( &progressbar );

		while( 1 )
		{

			u32 is_finished = 1;

			i = 1;
			while( 1 )
			{

				is_finished += p[ i ].is_finished;

				i++;
				if ( i >= cores ) { break; }
			}

			double d = (double) is_finished * progressbar.slice;
			n_paint_progressbar_loop( &progressbar, d );

			if ( is_finished >= cores ) { break; }
		}

		n_paint_progressbar_exit( &progressbar );

		i = 1;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 1;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_paint_progressbar progressbar;
		n_paint_progressbar_init( &progressbar );

		n_type_int i = 1;
		while( 1 )
		{

			n_paint_load_thread_struct tmp = { name_base, bmp, layer_count, sx,sy, i,1, n_false };
			n_paint_load_thread( &tmp );

			i++;

			double d = (double) i * progressbar.slice;
			n_paint_progressbar_loop( &progressbar, d );

//n_win_hwndprintf_literal( progressbar.hgui, "%f", d );

			if ( i >= layer_count ) { break; }
		}

		n_paint_progressbar_exit( &progressbar );

	}


	return;
}

n_bool
n_paint_layer_load( const n_posix_char *cmdline )
{
//return n_true;
//n_posix_debug_literal( "%s", cmdline );

	n_bmp_free( &n_paint_bmp_name );
	n_bmp_free( &n_paint_bmp_scrl );
	n_bmp_free( &n_paint_bmp_wgrb );

//return n_true;


	n_posix_char *name;
	n_posix_char *name_ini;

	if ( n_posix_stat_is_dir( cmdline ) )
	{
		name     = n_string_path_carboncopy( cmdline );
		name_ini = n_string_path_make_new( name, N_PAINT_LAYER_INI_FILENAME );
	} else {
		name     = n_string_path_upperfolder_new( cmdline );
		name_ini = n_string_path_make_new( name, N_PAINT_LAYER_INI_FILENAME );
		if ( n_false == n_string_is_same( cmdline, name_ini ) )
		{
			n_string_path_free( name     );
			n_string_path_free( name_ini );

//n_posix_debug_literal( " %d %d %d ", n_paint_layer_count, grabber, tooltype );

			return n_true;
		}
	}
//return n_true;
//n_posix_debug_literal( "%s", name_ini );


	n_ini ini; n_ini_zero( &ini );
	n_bool ret = n_ini_load( &ini, name_ini );
//n_ini_free( &ini ); ret = n_true;


	if ( ret == n_false )
	{
		ret = n_ini_section_chk( &ini, N_PAINT_LAYER_INI_SECTION );
//n_posix_debug_literal( " n_ini_section_chk_literal() : %d ", ret );
		if ( ret ) { ret = n_false; } else { ret = n_true; }
	}
//n_ini_free( &ini ); ret = n_true;


	if ( ret == n_false )
	{

		n_bmp_layer_free( n_paint_layer_data );
		n_memory_free( n_paint_layer_data );

		n_memory_free( n_paint_layer_is_mod );


		n_type_int p_layer_count = n_paint_layer_count;

		n_paint_layer_count = n_ini_value_int( &ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_NUMBER, N_PAINT_LAYER_MAX );
		if ( n_paint_layer_count < N_PAINT_LAYER_MAX ) { n_paint_layer_count = N_PAINT_LAYER_MAX; }

		if ( p_layer_count != n_paint_layer_count ) { ShowWindow( hwnd_layr, SW_HIDE ); }

		n_paint_layer_data = n_memory_new( sizeof( n_paint_layer ) * n_paint_layer_count );
		n_memory_zero( n_paint_layer_data, sizeof( n_paint_layer ) * n_paint_layer_count );

		n_paint_layer_is_mod = n_memory_new( sizeof( n_posix_bool ) * n_paint_layer_count );
		n_memory_padding_int( n_paint_layer_is_mod, n_false, n_paint_layer_count );


		n_bmp *bmp_layer = n_memory_new_closed( sizeof( n_bmp ) * n_paint_layer_count );
		n_memory_zero( bmp_layer, sizeof( n_bmp ) * n_paint_layer_count );


		n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%d.png", 0 );
		n_posix_char *name_img = n_string_path_make_new( name, str );
//n_posix_debug_literal( " %s ", p->name_img );

		n_posix_bool ret2 = n_png_png2bmp( name_img, &bmp_layer[ 0 ] );

		n_string_path_free( name_img );


		if ( ret2 == n_false )
		{

			n_paint_load_main( name, bmp_layer, n_paint_layer_count, N_BMP_SX( &bmp_layer[ 0 ] ), N_BMP_SY( &bmp_layer[ 0 ] ) );

			n_type_int i = 0;
			while( 1 )
			{
				n_bmp_free_fast( &n_paint_layer_data[ i ].bmp_data );
				n_bmp_alias( &bmp_layer[ i ], &n_paint_layer_data[ i ].bmp_data );

				i++;
				if ( i >= n_paint_layer_count ) { break; }
			}

		}


		n_memory_free_closed( bmp_layer );

	}


	if ( ret == n_false )
	{
		n_paint_layer_name_init( name );

		n_memory_padding_int( n_paint_layer_is_mod, n_false, n_paint_layer_count );


		n_type_gfx sx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
		n_type_gfx sy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

		if ( n_paint_fastmode )
		{
			n_bmp_new_fast( &n_paint_bmp_scrl, sx, sy );
			n_paint_cache_zero( &n_paint_bmp_scrl );
		}

		n_paint_layer_ui_init( name, &ini, n_false );

		extern void n_paint_layer_resize( HWND hwnd, n_bool shade_onoff, n_bool is_init );
		n_paint_layer_resize( hwnd_layr, n_paint_layer_shade_onoff, n_true );
	} else {
		n_ini_free( &ini );
	}


	n_string_path_free( name     );
	n_string_path_free( name_ini );


	return ret;
}

typedef struct {

	n_posix_char *name_base;
	n_bmp        *bmp;
	n_bool        is_mod;
	n_type_int    layer_count;
	n_type_int    oy, cores;

} n_paint_save_thread_struct;

void
n_paint_save_thread_main( n_paint_save_thread_struct *p )
{
//return;

	if ( p->oy >= p->layer_count ) { return; }


	n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%lld.png", p->oy );
	n_posix_char *png_name = n_string_path_make_new( p->name_base, str );

	// [!] : unsafe : don't use n_posix_stat_is_exist()


	FILE *fp = n_posix_fopen_read( png_name );

	if ( ( fp == NULL )||( p->is_mod ) )
	{
		n_png png = n_png_template;

		n_png_compress( &png, p->bmp );

		n_png_save( &png, png_name );

		n_png_free( &png );
	}

	n_posix_fclose( fp );


	n_string_path_free( png_name );


	return;
}

n_thread_return
n_paint_save_thread( n_thread_argument p )
{

	n_paint_save_thread_main( (void*) p );

	return 0;
}

void
n_paint_save_main( n_posix_char *name_base, n_type_int layer_count )
{

	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_paint_thread_onoff )
		&&
		( n_thread_onoff() )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_paint_save_main() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		n_type_int cores = layer_count;//n_thread_core_count;

		n_thread                   *h = (void*) n_memory_new( cores * sizeof( n_thread                   ) );
		n_paint_save_thread_struct *p = (void*) n_memory_new( cores * sizeof( n_paint_save_thread_struct ) );

		n_type_int i = 0;
		while( 1 )
		{

			n_bmp        *bmp = &n_paint_layer_data[ i ].bmp_data;
			n_posix_bool  mod =  n_paint_layer_is_mod[ i ];

			n_paint_save_thread_struct tmp = { name_base, bmp, mod, layer_count, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_save_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_save_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_type_int i = 0;
		while( 1 )
		{

			n_bmp        *bmp = &n_paint_layer_data[ i ].bmp_data;
			n_posix_bool  mod =  n_paint_layer_is_mod[ i ];

			n_paint_save_thread_struct tmp = { name_base, bmp, mod, layer_count, i,1 };
			n_paint_save_thread( &tmp );

			i++;
			if ( i >= layer_count ) { break; }
		}

	}


	return;
}

void
n_paint_layer_save( void )
{

	n_bool is_init = n_false;

	n_posix_char *name = n_string_path_carboncopy( n_paint_bmpname );
	if ( n_paint_format_is_lyr( name ) ) { n_string_path_ext_del( name ); }

//n_posix_debug_literal( " %d : %s ", n_posix_stat_is_dir( n_paint_layer_name_main ), n_paint_layer_name_main );
//n_posix_debug_literal( "%s\n%s", name, n_paint_layer_name_main );

	if ( n_string_is_same( name, n_paint_layer_name_main ) )
	{

		n_paint_layer_first_index = n_paint_layer_txtbox.select_cch_y;

	} else {

		is_init = n_true;

		n_paint_layer_onoff = n_true;
		n_paint_layer_count = N_PAINT_LAYER_MAX;

		n_paint_layer_first_index = 0;

		n_type_gfx bmpsx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
		n_type_gfx bmpsy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

		n_type_int i = 1;
		while( 1 )
		{
			n_bmp_new( &n_paint_layer_data[ i ].bmp_data, bmpsx, bmpsy );
			n_bmp_flush( &n_paint_layer_data[ i ].bmp_data, n_bmp_white_invisible );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

		n_paint_layer_config_default();

		i = 0;
		while( 1 )
		{

			n_string_truncate( n_paint_layer_data[ i ].name );

			if ( i == 0 )
			{
				n_posix_strcat( n_paint_layer_data[ i ].name, n_posix_literal( "Background" ) );
			} else
			if ( i == ( n_paint_layer_count - 1 ) )
			{
				n_posix_strcat( n_paint_layer_data[ i ].name, n_posix_literal( "Top" ) );
			}

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}


		n_ini_new( &n_paint_layer_ini );

		n_paint_layer_ini_write( &n_paint_layer_ini );

//n_posix_debug_literal( " %d ", n_paint_layer_data[ 0 ].percent );

		n_memory_padding_int( n_paint_layer_is_mod, n_false, n_paint_layer_count );

	}

	n_paint_layer_name_exit();
	n_paint_layer_name_init( name );


	n_posix_mkdir( name );


	//if ( 0 )
	{

		n_paint_save_main( name, n_paint_layer_count );

		if ( is_init == n_false )
		{
			n_memory_padding_int( n_paint_layer_is_mod, n_false, n_paint_layer_count );
		}

	}


	n_posix_char *ini_name = n_string_path_make_new( name, N_PAINT_LAYER_INI_FILENAME );
//n_posix_debug_literal( " %s ", ini_name );

	n_paint_layer_ini_write( &n_paint_layer_ini );

/*
	{

		n_type_int i = 0;
		while( 1 )
		{
n_posix_debug_literal( " %s ", n_paint_layer_data[ i ].name );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}
	}

	{

		n_type_int i = 0;
		while( 1 )
		{
			if ( i >= n_paint_layer_ini.sy ) { break; }

n_posix_debug_literal( " %s ", n_paint_layer_ini.line[ i ] );

			i++;
		}
	}
*/
	n_ini_save( &n_paint_layer_ini, ini_name );

	n_string_path_free( ini_name );


	n_paint_layer_ui_init( name, &n_paint_layer_ini, n_false );


	n_string_path_free( name );


	return;
}

void
n_paint_layer_grabber_location( n_type_int y )
{
/*
	if ( y >= 0 )
	{
n_win_hwndprintf_literal( hwnd_layr, "%s : %s", N_PAINT_LAYER_TITLE, n_paint_layer_data[ y ].name );
	} else {
n_win_hwndprintf_literal( hwnd_layr, "%s", N_PAINT_LAYER_TITLE );
	}

	return;
*/

	n_type_int i = 0;
	while( 1 )
	{

		n_bool refresh = n_false;

		n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, i );

		if ( nam[ 1 ] == n_posix_literal( 'u' ) )
		{
			refresh  = n_true;
			nam[ 1 ] = n_posix_literal( ' ' );
		} else
		if ( nam[ 1 ] == n_posix_literal( 'U' ) )
		{
			refresh  = n_true;
			nam[ 1 ] = n_posix_literal( 'B' );
		}

		if ( refresh ) { n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam ); }

		n_string_free( nam );

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


//n_win_hwndprintf_literal( hwnd_layr, "%d", y );


	n_paint_layer_multiselect = 0;


	i = 0;
	while( 1 )
	{//break;

		if (
			( y != -1 )
			&&
			( n_paint_grabber_wholegrb_onoff )
			&&
			( n_paint_layer_data[ i ].visible == n_false )
		)
		{
			n_paint_layer_multiselect++;
		} else
		if (
			( y != -1 )
			&&
			( n_paint_grabber_wholegrb_onoff )
			&&
			( n_paint_layer_data[ i ].visible )
		)
		{
			n_paint_layer_multiselect++;

			n_bool refresh = n_false;

			n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, i );

			if ( nam[ 1 ] == n_posix_literal( ' ' ) )
			{
				refresh  = n_true;
				nam[ 1 ] = n_posix_literal( 'u' );
			} else
			if ( nam[ 1 ] == n_posix_literal( 'B' ) )
			{
				refresh  = n_true;
				nam[ 1 ] = n_posix_literal( 'U' );
			}

			if ( refresh ) { n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam ); }

			n_string_free( nam );
		} else
		if ( i == y )
		{
			n_paint_layer_multiselect++;

			n_bool refresh = n_false;

			n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, i );

			if ( nam[ 1 ] == n_posix_literal( ' ' ) )
			{
				refresh  = n_true;
				nam[ 1 ] = n_posix_literal( 'u' );
			} else
			if ( nam[ 1 ] == n_posix_literal( 'B' ) )
			{
				refresh  = n_true;
				nam[ 1 ] = n_posix_literal( 'U' );
			}

			if ( refresh ) { n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam ); }

			n_string_free( nam );
		}

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );


	return;
}

void
n_paint_layer_visibility_off( n_type_int y )
{

	n_posix_char *nam = n_win_txtbox_selection_new( &n_paint_layer_txtbox );

	if ( nam[ 1 ] == n_posix_literal( 'B' ) )
	{
		nam[ 1 ] = n_posix_literal( ' ' );
		n_paint_layer_data[ y ].visible = n_false;
	} else
	if ( nam[ 1 ] == n_posix_literal( ' ' ) )
	{
		//
		n_paint_layer_data[ y ].visible = n_false;
	}
	if ( nam[ 1 ] == n_posix_literal( 'U' ) )
	{
		nam[ 1 ] = n_posix_literal( ' ' );
		n_paint_layer_data[ y ].visible = n_false;
	} else
	if ( nam[ 1 ] == n_posix_literal( 'u' ) )
	{
		nam[ 1 ] = n_posix_literal( ' ' );
		n_paint_layer_data[ y ].visible = n_false;
	}
//n_posix_debug_literal( "%s", str );

	n_win_txtbox_line_mod( &n_paint_layer_txtbox, y, nam );

	n_string_free( nam );


	n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );


	n_paint_refresh_client();


	return;
}

void
n_paint_layer_visibility_onoff( n_type_int y )
{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( n_paint_layer_txtbox.hwnd ), "%d", n_paint_layer_txtbox.select_cch_y );


	n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, y );

	if ( nam[ 1 ] == n_posix_literal( 'B' ) )
	{
		nam[ 1 ] = n_posix_literal( ' ' );
		n_paint_layer_data[ y ].visible = n_false;
	} else
	if ( nam[ 1 ] == n_posix_literal( ' ' ) )
	{
		nam[ 1 ] = n_posix_literal( 'B' );
		n_paint_layer_data[ y ].visible = n_true;
	}
	if ( nam[ 1 ] == n_posix_literal( 'U' ) )
	{
		nam[ 1 ] = n_posix_literal( 'u' );
		n_paint_layer_data[ y ].visible = n_false;
	} else
	if ( nam[ 1 ] == n_posix_literal( 'u' ) )
	{
		nam[ 1 ] = n_posix_literal( 'U' );
		n_paint_layer_data[ y ].visible = n_true;
	}
//n_posix_debug_literal( "%s", str );

	n_win_txtbox_line_mod( &n_paint_layer_txtbox, y, nam );

	n_string_free( nam );


	if ( n_paint_layer_data[ y ].visible )
	{
		n_paint_bmp_data = &n_paint_layer_data[ y ].bmp_data;
	}


	n_paint_layer_txtbox.select_cch_y = y;

	n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );


	n_paint_cache_zero( &n_paint_bmp_scrl );


	n_paint_refresh_client();


	return;
}

void
n_paint_layer_visibility_onoff_all( n_bool onoff )
{

	n_type_int i = 0;
	while( 1 )
	{

		n_posix_char *nam = n_win_txtbox_line_get_new( &n_paint_layer_txtbox, i );

		if ( onoff )
		{

			n_paint_layer_data[ i ].visible = n_true;


			if ( nam[ 1 ] == n_posix_literal( 'u' ) )
			{
				nam[ 1 ] = n_posix_literal( 'U' );
			} else
			if ( nam[ 1 ] == n_posix_literal( ' ' ) )
			{
				nam[ 1 ] = n_posix_literal( 'B' );
			}

			n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam );

		} else {

			n_paint_layer_data[ i ].visible = n_false;


			if ( nam[ 1 ] == n_posix_literal( 'U' ) )
			{
				nam[ 1 ] = n_posix_literal( 'u' );
			} else
			if ( nam[ 1 ] == n_posix_literal( 'B' ) )
			{
				nam[ 1 ] = n_posix_literal( ' ' );
			}

			n_win_txtbox_line_mod( &n_paint_layer_txtbox, i, nam );

		}

		n_string_free( nam );


		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );


	n_paint_refresh_client();


	return;
}

void
n_paint_layer_rename_off( void )
{

	n_paint_layer_rename_onoff = n_false;


	ShowWindow( n_paint_layer_rename.hwnd, SW_HIDE );


	SetFocus( hwnd_layr );
	n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );


	return;
}

void
n_paint_layer_rename_go( void )
{

	if ( n_paint_layer_rename_onoff == n_false )
	{

		n_paint_layer_rename_onoff = n_true;

		n_posix_char *str = n_win_txtbox_selection_new( &n_paint_layer_txtbox );
		n_string_copy( &str[ 3 ], str );

		n_win_txtbox_line_mod( &n_paint_layer_rename, 0, str );
		n_string_free( str );

		n_win_txtbox_select_tail_set( &n_paint_layer_rename );

		n_type_gfx tx,ty,sx,sy; n_win_rect_expand_size( &n_paint_layer_txtbox.highlight_rect, &tx,&ty,&sx,&sy );
		n_win_move_simple( n_paint_layer_rename.hwnd, tx, ty, sx, sy, n_false );

		ShowWindow( n_paint_layer_rename.hwnd, SW_SHOWNA );
		SetFocus( n_paint_layer_rename.hwnd );

	} else {

		n_paint_layer_rename_onoff = n_false;


		n_posix_char *str = n_win_txtbox_selection_new( &n_paint_layer_rename );
		if ( N_PAINT_LAYER_CCH <= n_posix_strlen( str ) )
		{
			str[ N_PAINT_LAYER_CCH - 1 ] = N_STRING_CHAR_NUL;
		}
//n_posix_debug_literal( "%s", str );

		n_string_copy( str, n_paint_layer_data[ n_paint_layer_rename_target ].name );


		n_posix_char nam[ N_PAINT_LAYER_CCH ];
		if ( n_paint_layer_multiselect )
		{
			if ( n_paint_layer_data[ n_paint_layer_rename_target ].visible )
			{
				n_posix_sprintf_literal( nam, "[U]%s", str );
			} else {
				n_posix_sprintf_literal( nam, "[u]%s", str );
			}
		} else {
			if ( n_paint_layer_data[ n_paint_layer_rename_target ].visible )
			{
				n_posix_sprintf_literal( nam, "[B]%s", str );
			} else {
				n_posix_sprintf_literal( nam, "[ ]%s", str );
			}
		}

		n_win_txtbox_line_mod( &n_paint_layer_txtbox, n_paint_layer_rename_target, nam );


		n_string_free( str );


		ShowWindow( n_paint_layer_rename.hwnd, SW_HIDE );


		SetFocus( hwnd_layr );
		n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );


		n_bmp_free( &n_paint_bmp_name );

		n_paint_refresh_client();

	}


	return;
}

void
n_paint_layer_grabber_check_enable( n_bool onoff )
{

	n_win_check_onoff( &n_paint_layer_chk_wholegrb, onoff );
	n_win_check_onoff( &n_paint_layer_chk_wholepvw, onoff );


	return;
}

void
n_paint_layer_grabber_uncheck( void )
{

	n_paint_grabber_wholegrb_onoff = n_false;
	n_paint_whole_preview_onoff    = n_false;

	n_win_check_uncheck( &n_paint_layer_chk_wholegrb );
	n_win_check_uncheck( &n_paint_layer_chk_wholepvw );


	return;
}

void
n_paint_layer_grabber_move( n_type_int fy, n_type_int ty )
{

	if ( n_paint_layer_data[ ty ].visible )
	{
		n_bmp bmp = n_paint_layer_data[ fy ].bmp_grab;
		n_paint_layer_data[ fy ].bmp_grab = n_paint_layer_data[ ty ].bmp_grab;
		n_paint_layer_data[ ty ].bmp_grab = bmp;

		n_paint_bmp_data = &n_paint_layer_data[ ty ].bmp_data;
		n_paint_bmp_grab = &n_paint_layer_data[ ty ].bmp_grab;

		n_paint_grabber_selected_index = ty;

		//n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%s", n_paint_layer_data[ ty ].name );
		//n_win_statusbar_od_text( &n_paint_layer_statusbar, str, 0 );

		n_paint_layer_grabber_location( ty );

		n_win_txtbox_refresh( &n_paint_layer_txtbox, N_WIN_TXTBOX_NONNON_PAINT );

		n_paint_refresh_client();
	}


	return;
}

void
n_paint_layer_resize( HWND hwnd, n_bool shade_onoff, n_bool is_init )
{

	n_type_gfx ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );

	n_type_gfx pad = m;


	n_win_txtbox_metrics_canvas( &n_paint_layer_txtbox );
//n_posix_debug_literal( " %d ", n_paint_layer_txtbox.cell_pxl_sy );


	int set = n_paint_layer_count + 2;

	if ( n_paint_layer_scroll_onoff )
	{
		set = n_posix_minmax( 16, n_paint_layer_count, 16 ) + 2;
	}

	n_type_gfx csy = ( n_paint_layer_txtbox.cell_pxl_sy * set ) + ( ctl * 4 );

	n_type_gfx gap = m * 2;
	n_type_gfx csx = ( ico * 5 ) + ( gap * 4 );

	n_type_gfx tmp_csx = csx + m;
	n_type_gfx tmp_csy = csy + m;

	if ( shade_onoff ) { tmp_csy = 0; }

	int nw = N_WIN_SET_DEFAULT;
	if ( is_init ) { nw = N_WIN_SET_NEEDPOS; }

	if ( nwin_layr.posx == -1 ) { nwin_layr.posx = nwin_tool.posx + nwin_tool.wsx + ctl; }
	if ( nwin_layr.posy == -1 ) { nwin_layr.posy = nwin_tool.posy; }

#ifdef _MSC_VER

	//

#else  // #ifdef _MSC_VER

	// [!] : MinGW version only

	if ( n_win_dwm_is_on() )
	{
		static n_bool init_onoff = n_false;
		if ( init_onoff == n_false )
		{
			init_onoff = n_true;

			nwin_layr.posx += 5;
			nwin_layr.posy += 5;
		}
	}

#endif // #ifdef _MSC_VER


	n_win_set( hwnd, &nwin_layr, tmp_csx + ( pad * 2 ), tmp_csy + ( pad * 2 ), nw );

	n_type_gfx x = pad;
	n_type_gfx y = pad;

	n_win_move(  n_paint_layer_txtbox      .hwnd, x,                     y, csx, csy-(ctl*4), n_true );
	nwscr_move( &n_paint_layer_scr_blend        , x, csy - ( ctl * 1 ) + y, csx,         ctl, n_true );
	nwscr_move( &n_paint_layer_scr_blur         , x, csy - ( ctl * 2 ) + y, csx,         ctl, n_true );
	n_win_move(  n_paint_layer_chk_wholegrb.hwnd, x, csy - ( ctl * 3 ) + y, csx,         ctl, n_true );
	n_win_move(  n_paint_layer_chk_wholepvw.hwnd, x, csy - ( ctl * 4 ) + y, csx,         ctl, n_true );


	return;
}

void
n_paint_layer_resize_check( HWND hwnd )
{

	n_type_gfx ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );


	//n_win_txtbox_metrics_canvas( &n_paint_layer_txtbox );


	n_type_gfx set = n_paint_layer_count + 2;

	if ( n_paint_layer_scroll_onoff )
	{
		set = n_posix_minmax( 16, n_paint_layer_count, 16 ) + 2;
	}

	n_type_gfx csy = ( n_paint_layer_txtbox.cell_pxl_sy * set ) + ( ctl * 3 );

	n_type_gfx gap = m * 2;
	n_type_gfx csx = ( ico * 5 ) + ( gap * 4 );

	// [x] : don't use n_true : heavy

	n_win_move(  n_paint_layer_chk_wholegrb.hwnd, 0, csy - ( ctl * 3 ), csx,         ctl, n_false );

	n_win_refresh( hwnd, n_false );


	return;
}

LRESULT CALLBACK
n_paint_layer_scroll_callback( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{
//n_posix_debug_literal( "" );

	if ( n_paint_layer_rename_onoff )
	{
		n_paint_layer_rename_off();
	}

	return 0;
}

LRESULT CALLBACK
n_paint_layer_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id_on_settingchange = 0;
	static UINT timer_id_on_blend_or_blur = 0;

	static n_type_int click_started_index = -1;


	n_paint_xmouse( hwnd, msg );


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id_on_settingchange == 0 ) { timer_id_on_settingchange = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id_on_settingchange, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == timer_id_on_settingchange )
		{
			n_win_timer_exit( hwnd, timer_id_on_settingchange );


			n_project_darkmode();

			n_win_init_background( hwnd );
			n_win_refresh( hwnd, n_true );


			n_win_txtbox_on_settingchange( &n_paint_layer_txtbox );

			n_win_scroller_on_settingchange( &n_paint_layer_scr_blend );
			n_win_scroller_on_settingchange( &n_paint_layer_scr_blur  );
		} else
		if ( wparam == timer_id_on_blend_or_blur )
		{
			n_win_timer_exit( hwnd, timer_id_on_blend_or_blur );


			SetCursor( LoadCursor( NULL, IDC_WAIT ) );


			n_paint_cache_zero( &n_paint_bmp_scrl );
			n_paint_cache_zero( &n_paint_bmp_wgrb );

			n_paint_refresh_client_id( N_PAINT_REFRESH_ID_LAYER );


			n_win_cursor_add( NULL, IDC_ARROW );
		}

	break;


	case WM_CREATE :


		// Global


		// Window

		n_win_init_literal( hwnd, "", "", "" );

		n_win_hwndprintf_literal( hwnd, "%s", N_PAINT_LAYER_TITLE );

		{
			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_LISTBOX;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			if ( n_paint_layer_scroll_onoff )
			{
				style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			}

			int style_option = 0;

			style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL;
			style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS;
			style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM;
			style_option = style_option | N_WIN_TXTBOX_OPTION_ZEROBASED_INDEX;
			style_option = style_option | N_WIN_TXTBOX_OPTION_COMBOBOX_NOGRAY;
			style_option = style_option | N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE;

			if ( n_win_fluent_ui_onoff )
			{
				style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;
			}

			n_win_txtbox_init( &n_paint_layer_txtbox, hwnd, style, style_option );

			n_paint_layer_txtbox.scroll_callback = n_paint_layer_scroll_callback;
		}

		{
			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_ONELINE;
			style = style | N_WIN_TXTBOX_STYLE_FLATBDR;

			int style_option = 0;

			n_win_txtbox_init( &n_paint_layer_rename, n_paint_layer_txtbox.hwnd, style, style_option );

			n_paint_layer_on_keydown_init();
		}

		n_win_scroller_init_literal( &n_paint_layer_scr_blend, hwnd, "Blend" );
		n_win_scroller_init_literal( &n_paint_layer_scr_blur , hwnd, "Blur"  );


		n_win_check_zero( &n_paint_layer_chk_wholegrb );
		n_win_check_init_literal( &n_paint_layer_chk_wholegrb, hwnd, "Whole Grab", CBS_UNCHECKEDNORMAL );

		n_win_check_zero( &n_paint_layer_chk_wholepvw );
		n_win_check_init_literal( &n_paint_layer_chk_wholepvw, hwnd, "Whole Preview", CBS_UNCHECKEDNORMAL );


		//n_win_statusbar_od_zero( &n_paint_layer_statusbar );
		//n_win_statusbar_od_init( &n_paint_layer_statusbar, hwnd, 1 );


		n_win_simplemenu_init( &n_paint_layer_simplemenu );

		n_win_simplemenu_set( &n_paint_layer_simplemenu,  0, NULL, n_posix_literal( "[ ]Up"                  ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  1, NULL, n_posix_literal( "[ ]Down"                ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  2, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  3, NULL, n_posix_literal( "[ ]Rename"              ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  4, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  5, NULL, n_posix_literal( "[ ]All Off"             ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  6, NULL, n_posix_literal( "[ ]All On"              ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  7, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  8, NULL, n_posix_literal( "[ ]This Only"           ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu,  9, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu, 10, NULL, n_posix_literal( "[ ]Grabber : Move Here" ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu, 11, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu, 12, NULL, n_posix_literal( "[ ]Thicken Lines"       ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu, 13, NULL, n_posix_literal( "[ ]Thin Lines"          ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu, 14, NULL, n_posix_literal( "[-]"                    ), NULL );
		n_win_simplemenu_set( &n_paint_layer_simplemenu, 15, NULL, n_posix_literal( "[ ]Add A New Layer"     ), NULL );

		n_paint_layer_simplemenu.callback      = n_win_txtbox_callback;
		n_paint_layer_simplemenu.callback_data = &n_paint_layer_txtbox;


		// Style

		//n_win_style_new  ( hwnd, N_WS_FIXEDWINDOW    );
		//n_win_sysmenu_disable( hwnd, 0,0,1, 0,1, 1, 1 );

		n_win_style_new( hwnd, WS_POPUP | WS_CAPTION );


		// Size

		n_paint_layer_resize( hwnd, n_paint_layer_shade_onoff, n_true );


		// Display

		ShowWindow( hwnd, SW_HIDE );

	break;


	case WM_NCLBUTTONDBLCLK :

		if ( n_paint_layer_shade_onoff )
		{
			n_paint_layer_shade_onoff = n_false;
		} else {
			n_paint_layer_shade_onoff = n_true;
		}

		n_paint_layer_resize( hwnd, n_paint_layer_shade_onoff, n_false );

	break;


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{
//n_win_debug_count( hwnd );
			if ( n_paint_layer_rename_onoff )
			{
				n_paint_layer_rename_off();
			}
		}

	break;


	case WM_SETFOCUS :

		SetFocus( n_paint_layer_txtbox.hwnd );

	break;


	case WM_COMMAND :
	{

		if ( (HWND) lparam == n_paint_layer_txtbox.hwnd )
		{
//n_posix_debug_literal( "%d", wparam );
//n_win_hwndprintf_literal( hwnd, "%d", wparam );

			if ( wparam == WM_LBUTTONDOWN )
			{
//break;
				n_type_int y = n_paint_layer_txtbox.select_cch_y;
//n_posix_debug_literal( "%d", y );

				n_paint_bmp_data = &n_paint_layer_data[ y ].bmp_data;

				if ( n_paint_grabber_wholegrb_onoff )
				{
					n_paint_bmp_grab = &n_paint_layer_data[ y ].bmp_grab;
				}


				// [!] : grabbed and edit mode returns tooltype TOOL_TYPE_PEN or so
//n_win_hwndprintf_literal( hwnd, "%d", tooltype );

				if (
//(0)&&
					( tooltype == N_PAINT_TOOL_TYPE_GRAB )
					&&
					( n_false == N_PAINT_GRABBER_IS_NEUTRAL() )
					&&
					( n_paint_grabber_wholegrb_onoff == n_false )
					&&
					( n_win_is_input( VK_SHIFT ) )
				)
				{
					n_type_int fy = n_paint_grabber_selected_index;
					n_type_int ty = y;

					n_paint_layer_grabber_move( fy, ty );
				}


				int percent = n_paint_layer_data[ y ].percent;
				if ( y == 0 ) { percent = 100; }

				n_win_hwndprintf_literal( n_paint_layer_scr_blend.value, "%3d%%", percent );
				n_win_refresh( n_paint_layer_scr_blend.value, n_true );

				n_paint_layer_scr_blend.scrollbar.unit_pos = percent;
				n_win_scrollbar_draw_always( &n_paint_layer_scr_blend.scrollbar, n_true );


				int blur = n_paint_layer_data[ y ].blur;

				n_win_hwndprintf_literal( n_paint_layer_scr_blur.value, "%3d", blur );
				n_win_refresh( n_paint_layer_scr_blur.value, n_true );

				n_paint_layer_scr_blur.scrollbar.unit_pos = blur;
				n_win_scrollbar_draw_always( &n_paint_layer_scr_blur.scrollbar, n_true );


				if ( y == 0 )
				{
					nwscr_enable( &n_paint_layer_scr_blend, n_false );
				} else {
					nwscr_enable( &n_paint_layer_scr_blend, n_true  );
				}


				if ( n_paint_layer_rename_onoff )
				{
					if ( n_paint_layer_rename_target != y )
					{
						n_paint_layer_rename_go();
					}
				} else {
					n_paint_layer_rename_target = y;
				}


				extern void n_paint_grabber_resync_auto_fast( void );
				n_paint_grabber_resync_auto_fast();


				n_bmp_free( &n_paint_bmp_name );

				static n_type_int prv_y = -1;

				if ( prv_y != y )
				{
					n_paint_bmp_name_count++;
				}

				prv_y = y;

				n_paint_refresh_layer_name();

			} else
			if ( wparam == WM_LBUTTONDBLCLK )
			{
				if ( n_paint_layer_rename_onoff ) { break; }

				if ( n_paint_layer_multiselect )
				{
					// [!] : something is needed
					n_project_dialog_info( hwnd_main, n_posix_literal( "Sorry, not implemented yet." ) );
				} else {
					n_paint_layer_visibility_onoff( n_paint_layer_txtbox.select_cch_y );
				}
			} else
			if ( ( wparam == WM_MBUTTONDOWN )||( wparam == WM_RBUTTONDOWN ) )
			{
				if ( n_false == n_win_is_hovered( n_paint_layer_txtbox.hwnd ) )
				{
//n_win_hwndprintf_literal( hwnd, "not hovered" );
					break;
				}
//n_win_hwndprintf_literal( hwnd, "hovered : %d", n_paint_layer_txtbox.select_cch_y );

				click_started_index = n_paint_layer_txtbox.select_cch_y;

				if ( n_win_simplemenu_target != NULL )
				{
					n_win_simplemenu_hide( n_win_simplemenu_target );
				}

				n_paint_layer_rename_target = n_paint_layer_txtbox.select_cch_y;
				n_paint_layer_menu_target   = n_paint_layer_txtbox.select_cch_y;


				n_type_int y = n_paint_layer_txtbox.select_cch_y;

				n_bmp_free( &n_paint_bmp_name );

				static n_type_int prv_y = -1;

				if ( prv_y != y )
				{
					n_paint_bmp_name_count++;
				}

				prv_y = y;

				n_paint_refresh_client();

			} else
			if ( wparam == WM_RBUTTONUP )
			{
//n_posix_debug_literal( "%d", n_paint_layer_txtbox.hover_cch_y );
				if ( click_started_index != n_paint_layer_txtbox.hover_cch_y )
				{
					click_started_index = -1;
					break;
				} else {
					click_started_index = -1;
				}

				if ( n_paint_layer_rename_onoff ) { break; }

				if ( n_paint_layer_menu_target != n_paint_layer_txtbox.hover_cch_y ) { break; }

				if ( n_paint_layer_txtbox.hover_cch_y >= n_paint_layer_count ) { break; }
				n_win_simplemenu_show( &n_paint_layer_simplemenu, hwnd );

				n_paint_layer_menu_target = n_false;
			} else
			if ( wparam == WM_MBUTTONUP )
			{
				if ( click_started_index != n_paint_layer_txtbox.hover_cch_y )
				{
					click_started_index = -1;
					break;
				} else {
					click_started_index = -1;
				}

				if ( n_paint_layer_rename_onoff ) { break; }

				n_paint_layer_visibility_onoff_all( n_false );
				n_paint_layer_visibility_onoff( n_paint_layer_txtbox.hover_cch_y );
			}// else

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( &n_paint_layer_scr_blend ) )
		{

			n_type_int y = n_paint_layer_txtbox.select_cch_y;

			n_type_gfx prev = n_paint_layer_data[ y ].percent;

			n_paint_layer_data[ y ].percent = (int) wparam;
			n_paint_layer_data[ y ].blend   = (double) n_paint_layer_data[ y ].percent * 0.01;

			if ( prev == wparam ) { break; }

			n_win_hwndprintf_literal( n_paint_layer_scr_blend.value, "%3d%%", wparam );
			n_win_refresh( n_paint_layer_scr_blend.value, n_true );

			n_paint_layer_scr_blend.scrollbar.unit_pos = (double) wparam;
			n_win_scrollbar_draw_always( &n_paint_layer_scr_blend.scrollbar, n_true );


			if ( timer_id_on_blend_or_blur == 0 ) { timer_id_on_blend_or_blur = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, timer_id_on_blend_or_blur, N_PAINT_TIMEOUT );

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( &n_paint_layer_scr_blur ) )
		{

			n_type_int y = n_paint_layer_txtbox.select_cch_y;

			n_type_gfx prev = n_paint_layer_data[ y ].blur;

			n_paint_layer_data[ y ].blur = (int) wparam;

			if ( prev == wparam ) { break; }

			n_win_hwndprintf_literal( n_paint_layer_scr_blur.value, "%3d", wparam );
			n_win_refresh( n_paint_layer_scr_blur.value, n_true );

			n_paint_layer_scr_blur.scrollbar.unit_pos = (double) wparam;
			n_win_scrollbar_draw_always( &n_paint_layer_scr_blur.scrollbar, n_true );


			if ( timer_id_on_blend_or_blur == 0 ) { timer_id_on_blend_or_blur = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, timer_id_on_blend_or_blur, N_PAINT_TIMEOUT );

		} else

		if ( (HWND) lparam == n_paint_layer_chk_wholegrb.hwnd )
		{

			n_paint_grabber_wholegrb_onoff = n_win_check_is_checked( &n_paint_layer_chk_wholegrb );

			n_paint_grabber_resync_auto();


			// [!] : for scroll-wheeler

			SetFocus( hwnd_layr );

		} else
		if ( (HWND) lparam == n_paint_layer_chk_wholepvw.hwnd )
		{

			n_paint_cache_zero( &n_paint_bmp_scrl );
			n_paint_cache_zero( &n_paint_bmp_wgrb );


			n_paint_whole_preview_onoff = n_win_check_is_checked( &n_paint_layer_chk_wholepvw );

			n_paint_refresh_client();


			// [!] : for scroll-wheeler

			SetFocus( hwnd_layr );

		} else

		if ( (HWND) lparam == n_paint_layer_simplemenu.hwnd )
		{

			n_type_int y = n_paint_layer_txtbox.select_cch_y;

			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
//n_win_hwndprintf_literal( hwnd, " %d ", n_paint_layer_multiselect );

				if ( n_paint_layer_multiselect >= 2 )
				{
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  0, 'x' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  1, 'x' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  5, 'x' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  6, 'x' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  8, 'x' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu, 10, 'x' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu, 12, 'x' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu, 13, 'x' );
				} else {
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  0, ' ' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  1, ' ' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  5, ' ' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  6, ' ' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  8, ' ' );
					if (
						( N_PAINT_GRABBER_IS_NEUTRAL() )
						||
						( n_false == n_paint_layer_data[ y ].visible )
					)
					{
						n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu, 10, 'x' );
					} else {
						n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu, 10, ' ' );
					}
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu, 12, ' ' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu, 13, ' ' );
				}

				// [!] : after above code
				if ( y == 0 )
				{
//n_posix_debug_literal( " %d ", n_paint_layer_txtbox.select_cch_y );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  0, 'x' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  1, ' ' );
				} else
				if ( y == ( n_paint_layer_count - 1 ) )
				{
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  0, ' ' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  1, 'x' );
				} else {
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  0, ' ' );
					n_win_simplemenu_tweak_literal( &n_paint_layer_simplemenu,  1, ' ' );
				}
			} else
			if ( wparam == 0 )
			{
				n_paint_layer_swap_up( y );
			} else
			if ( wparam == 1 )
			{
				n_paint_layer_swap_down( y );
			} else
			if ( wparam == 2 )
			{
				//
			} else
			if ( wparam == 3 )
			{
				n_paint_layer_rename_go();
			} else
			if ( wparam == 4 )
			{
				//
			} else
			if ( wparam == 5 )
			{
				n_paint_layer_visibility_onoff_all( n_false );
			} else
			if ( wparam == 6 )
			{
				n_paint_layer_visibility_onoff_all( n_true  );
			} else
			if ( wparam == 7 )
			{
				//
			} else
			if ( wparam == 8 )
			{
				n_paint_layer_visibility_onoff_all( n_false );
				n_paint_layer_visibility_onoff( n_paint_layer_txtbox.select_cch_y );
			} else
			if ( wparam == 9 )
			{
				//
			} else
			if ( wparam == 10 )
			{
				n_type_int fy = n_paint_grabber_selected_index;
				n_type_int ty = n_paint_layer_txtbox.select_cch_y;

				n_paint_layer_grabber_move( fy, ty );
			} else
			if ( wparam == 11 )
			{
				//
			} else
			if ( wparam == 12 )
			{
				n_type_int y = n_paint_layer_txtbox.select_cch_y;

				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					n_bmp_thicken( &n_paint_layer_data[ y ].bmp_data );
				} else {
					n_bmp_thicken( &n_paint_layer_data[ y ].bmp_grab );
				}

				n_paint_layer_is_mod[ y ] = n_true;

				n_paint_cache_zero( &n_paint_bmp_scrl );
				n_paint_cache_zero( &n_paint_bmp_wgrb );

				n_paint_refresh_client();
			} else
			if ( wparam == 13 )
			{
				n_type_int y = n_paint_layer_txtbox.select_cch_y;

				if ( N_PAINT_GRABBER_IS_NEUTRAL() )
				{
					n_bmp_thin( &n_paint_layer_data[ y ].bmp_data );
				} else {
					n_bmp_thin( &n_paint_layer_data[ y ].bmp_grab );
				}

				n_paint_layer_is_mod[ y ] = n_true;

				n_paint_cache_zero( &n_paint_bmp_scrl );
				n_paint_cache_zero( &n_paint_bmp_wgrb );

				n_paint_refresh_client();
			} else
			if ( wparam == 14 )
			{
				//
			} else
			if ( wparam == 15 )
			{

				n_type_int i = n_paint_layer_count;

				n_paint_layer_data = n_memory_resize( n_paint_layer_data, sizeof( n_paint_layer ) * ( i + 1 ) );
				n_paint_layer_zero( &n_paint_layer_data[ i ] );

				n_paint_layer_is_mod = n_memory_resize( n_paint_layer_is_mod, sizeof( int ) * ( i + 1 ) );
				n_paint_layer_is_mod[ i ] = n_true;

				n_type_gfx sx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
				n_type_gfx sy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

				n_bmp_new( &n_paint_layer_data[ i ].bmp_data, sx,sy );

				n_bmp_flush( &n_paint_layer_data[ i ].bmp_data, n_bmp_white_invisible );

				n_bmp_free( &n_paint_bmp_name );
				n_paint_bmp_name_count++;

				n_win_txtbox_line_add( &n_paint_layer_txtbox, i, n_posix_literal( "[ ]" ) );

				n_paint_layer_count++;

				n_paint_layer_visibility_onoff( i );


				n_paint_layer_data[ i ].visible = n_true;
				n_paint_layer_data[ i ].percent =    100;
				n_paint_layer_data[ i ].blend   =    1.0;
				n_paint_layer_data[ i ].blur    =      0;

				int percent = 100;
				n_win_hwndprintf_literal( n_paint_layer_scr_blend.value, "%3d%%", percent );
				n_win_refresh( n_paint_layer_scr_blend.value, n_true );

				int blur = 0;
				n_win_hwndprintf_literal( n_paint_layer_scr_blur.value, "%3d", blur );
				n_win_refresh( n_paint_layer_scr_blur.value, n_true );

				n_win_scroller_scroll_parameter( &n_paint_layer_scr_blend, 1, 10, 100, percent, n_false );
				n_win_scroller_scroll_parameter( &n_paint_layer_scr_blur , 1,  5,  25, blur   , n_false );

				n_win_refresh( hwnd, n_posix_true );

				n_paint_layer_resize( hwnd, n_paint_layer_shade_onoff, n_false );

			}// else

		}

	}
	break;


	case WM_KEYDOWN :

	break;


	case WM_CLOSE :

		// [!] : for Alt + F4

		return 0;

	break;


	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}


	// [!] : IBEAM : Rename GUI first
 
	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_paint_layer_rename );
		if ( ret ) { return ret; }
	}

	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_paint_layer_txtbox );
		if ( ret ) { return ret; }
	}


	n_win_scroller_proc( hwnd, msg, wparam, lparam, &n_paint_layer_scr_blend );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, &n_paint_layer_scr_blur  );

	n_win_check_proc( hwnd, msg, wparam, lparam, &n_paint_layer_chk_wholegrb );
	n_win_check_proc( hwnd, msg, wparam, lparam, &n_paint_layer_chk_wholepvw );

	//n_win_statusbar_od_proc( hwnd, msg, wparam, lparam, &n_paint_layer_statusbar );

	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	n_paint_thumbnail_proc( hwnd, msg, wparam, lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


